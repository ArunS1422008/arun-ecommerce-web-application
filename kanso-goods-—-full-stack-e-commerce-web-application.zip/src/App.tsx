import {useCallback, useEffect, useState} from 'react';
import {AdminDashboardPage} from './components/AdminDashboardPage.tsx';
import {AuthPages} from './components/AuthPages.tsx';
import {CartPage} from './components/CartPage.tsx';
import {CheckoutPage} from './components/CheckoutPage.tsx';
import {Footer} from './components/Footer.tsx';
import {HomePage} from './components/HomePage.tsx';
import {Navbar} from './components/Navbar.tsx';
import {OrdersPage} from './components/OrdersPage.tsx';
import {ProductDetailPage} from './components/ProductDetailPage.tsx';
import {ProductsPage} from './components/ProductsPage.tsx';
import {ProfilePage} from './components/ProfilePage.tsx';
import {useTheme} from './hooks/useTheme.ts';
import {
  addToUserCart,
  fetchProducts,
  fetchUserCart,
  logoutAccount,
  mergeGuestCartApi,
  removeCartItemApi,
  updateCartQtyApi,
} from './services/api.ts';
import type {
  AuthUser,
  CartLineItem,
  OrderRecord,
  ProductCategory,
  ProductItem,
  ProductSortOption,
} from './types/store.ts';

export default function App() {
  const {theme, toggleTheme} = useTheme();

  const [currentPath, setCurrentPath] = useState<string>(() =>
    typeof window !== 'undefined' ? window.location.pathname || '/' : '/',
  );
  const [returnAfterAuthPath, setReturnAfterAuthPath] = useState<string | null>(null);

  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);

  const [products, setProducts] = useState<ProductItem[]>([]);
  const [productsLoading, setProductsLoading] = useState(true);
  const [productsError, setProductsError] = useState<string | null>(null);

  const [categoryFilter, setCategoryFilter] = useState<ProductCategory | 'All'>('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [sortOption, setSortOption] = useState<ProductSortOption>('featured');

  const [cartItems, setCartItems] = useState<CartLineItem[]>([]);
  const [recentOrderNumber, setRecentOrderNumber] = useState<string | null>(null);

  const navigate = useCallback((nextPath: string) => {
    setCurrentPath(nextPath);
    if (typeof window !== 'undefined' && window.location.pathname !== nextPath) {
      window.history.pushState({}, '', nextPath);
    }
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const loadProducts = useCallback(async () => {
    setProductsLoading(true);
    setProductsError(null);
    try {
      const data = await fetchProducts({
        category: categoryFilter,
        search: searchFilter,
        sort: sortOption,
      });
      setProducts(data);
    } catch (err) {
      setProductsError(err instanceof Error ? err.message : 'Unable to load products.');
    } finally {
      setProductsLoading(false);
    }
  }, [categoryFilter, searchFilter, sortOption]);

  useEffect(() => {
    void loadProducts();
  }, [loadProducts]);

  const handleAuthenticated = async (nextToken: string, nextUser: AuthUser) => {
    setToken(nextToken);
    setUser(nextUser);

    try {
      if (cartItems.length > 0) {
        const merged = await mergeGuestCartApi(
          nextToken,
          cartItems.map((i) => ({productId: i.productId, quantity: i.quantity})),
        );
        setCartItems(merged);
      } else {
        const saved = await fetchUserCart(nextToken);
        setCartItems(saved);
      }
    } catch {
      // Retain local items if merge fails
    }

    if (returnAfterAuthPath) {
      const target = returnAfterAuthPath;
      setReturnAfterAuthPath(null);
      navigate(target);
    } else if (nextUser.role === 'admin') {
      navigate('/admin');
    } else {
      navigate('/products');
    }
  };

  const handleLogout = async () => {
    if (token) {
      try {
        await logoutAccount(token);
      } catch {
        // Stateless JWT fallback
      }
    }
    setToken(null);
    setUser(null);
    setCartItems([]);
    setRecentOrderNumber(null);
    navigate('/');
  };

  const handleAddToCart = async (product: ProductItem, quantity = 1) => {
    if (product.stock < 1) return;

    if (token) {
      try {
        const updated = await addToUserCart(token, product.id, quantity);
        setCartItems(updated);
        return;
      } catch {
        // Fallback to local update if needed
      }
    }

    setCartItems((prev) => {
      const idx = prev.findIndex((item) => item.productId === product.id);
      if (idx === -1) {
        return [...prev, {productId: product.id, quantity: Math.min(quantity, product.stock), product}];
      }
      const nextQty = Math.min(prev[idx].quantity + quantity, product.stock);
      return prev.map((item, i) => (i === idx ? {...item, quantity: nextQty} : item));
    });
  };

  const handleUpdateCartQuantity = async (productId: string, quantity: number) => {
    if (token) {
      try {
        const updated = await updateCartQtyApi(token, productId, quantity);
        setCartItems(updated);
        return;
      } catch {
        // Fallback below
      }
    }

    if (quantity <= 0) {
      setCartItems((prev) => prev.filter((item) => item.productId !== productId));
      return;
    }

    setCartItems((prev) =>
      prev.map((item) =>
        item.productId === productId
          ? {...item, quantity: Math.min(quantity, item.product.stock)}
          : item,
      ),
    );
  };

  const handleRemoveCartItem = async (productId: string) => {
    if (token) {
      try {
        const updated = await removeCartItemApi(token, productId);
        setCartItems(updated);
        return;
      } catch {
        // Fallback below
      }
    }
    setCartItems((prev) => prev.filter((item) => item.productId !== productId));
  };

  const handleOrderPlaced = (order: OrderRecord) => {
    setCartItems([]);
    setRecentOrderNumber(order.orderNumber);
    void loadProducts();
    navigate('/orders');
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const featuredProducts = products.filter((p) => p.featured).length > 0
    ? products.filter((p) => p.featured)
    : products;

  const renderPage = () => {
    if (currentPath === '/') {
      return (
        <HomePage
          featuredProducts={featuredProducts}
          loading={productsLoading}
          onNavigate={navigate}
          onAddToCart={(p) => void handleAddToCart(p, 1)}
        />
      );
    }

    if (currentPath === '/products') {
      return (
        <ProductsPage
          products={products}
          loading={productsLoading}
          error={productsError}
          category={categoryFilter}
          search={searchFilter}
          sort={sortOption}
          onChangeCategory={setCategoryFilter}
          onChangeSearch={setSearchFilter}
          onChangeSort={setSortOption}
          onRetry={() => void loadProducts()}
          onViewDetails={(p) => navigate(`/products/${p.slug}`)}
          onAddToCart={(p) => void handleAddToCart(p, 1)}
        />
      );
    }

    if (currentPath.startsWith('/products/')) {
      const slugOrId = currentPath.slice('/products/'.length);
      return (
        <ProductDetailPage
          slugOrId={slugOrId}
          onBack={() => navigate('/products')}
          onAddToCart={(p, qty) => void handleAddToCart(p, qty)}
          onGoToCart={() => navigate('/cart')}
        />
      );
    }

    if (currentPath === '/cart') {
      return (
        <CartPage
          items={cartItems}
          onUpdateQuantity={(id, qty) => void handleUpdateCartQuantity(id, qty)}
          onRemoveItem={(id) => void handleRemoveCartItem(id)}
          onContinueShopping={() => navigate('/products')}
          onCheckout={() => navigate('/checkout')}
        />
      );
    }

    if (currentPath === '/checkout') {
      return (
        <CheckoutPage
          token={token}
          user={user}
          items={cartItems}
          onRequireLogin={() => {
            setReturnAfterAuthPath('/checkout');
            navigate('/login');
          }}
          onOrderPlaced={handleOrderPlaced}
          onBackToCart={() => navigate('/cart')}
        />
      );
    }

    if (currentPath === '/login' || currentPath === '/register') {
      return (
        <AuthPages
          mode={currentPath === '/register' ? 'register' : 'login'}
          onSwitchMode={(nextMode) => navigate(nextMode === 'register' ? '/register' : '/login')}
          onAuthenticated={(t, u) => void handleAuthenticated(t, u)}
        />
      );
    }

    if (currentPath === '/profile') {
      if (!token || !user) {
        return (
          <AuthPages
            mode="login"
            onSwitchMode={(m) => navigate(m === 'register' ? '/register' : '/login')}
            onAuthenticated={(t, u) => void handleAuthenticated(t, u)}
          />
        );
      }
      return (
        <ProfilePage
          token={token}
          user={user}
          onUserUpdated={setUser}
          onNavigate={navigate}
          onLogout={() => void handleLogout()}
        />
      );
    }

    if (currentPath === '/orders') {
      if (!token || !user) {
        return (
          <AuthPages
            mode="login"
            onSwitchMode={(m) => navigate(m === 'register' ? '/register' : '/login')}
            onAuthenticated={(t, u) => void handleAuthenticated(t, u)}
          />
        );
      }
      return (
        <OrdersPage
          token={token}
          highlightedOrderNumber={recentOrderNumber}
          onShopNow={() => navigate('/products')}
        />
      );
    }

    if (currentPath === '/admin') {
      if (!token || !user) {
        return (
          <AuthPages
            mode="login"
            onSwitchMode={(m) => navigate(m === 'register' ? '/register' : '/login')}
            onAuthenticated={(t, u) => void handleAuthenticated(t, u)}
          />
        );
      }
      return (
        <AdminDashboardPage
          token={token}
          user={user}
          products={products}
          onRefreshProducts={loadProducts}
        />
      );
    }

    return (
      <HomePage
        featuredProducts={featuredProducts}
        loading={productsLoading}
        onNavigate={navigate}
        onAddToCart={(p) => void handleAddToCart(p, 1)}
      />
    );
  };

  return (
    <div className="flex min-h-screen flex-col bg-stone-50 text-zinc-900 transition-colors duration-200 dark:bg-zinc-950 dark:text-zinc-100">
      <Navbar
        currentPath={currentPath}
        user={user}
        cartCount={cartCount}
        theme={theme}
        onToggleTheme={toggleTheme}
        onNavigate={navigate}
      />

      <main className="flex-1">{renderPage()}</main>

      <Footer theme={theme} onToggleTheme={toggleTheme} onNavigate={navigate} />
    </div>
  );
}
