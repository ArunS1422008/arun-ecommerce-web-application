import type {
  AuthResponse,
  AuthUser,
  CartLineItem,
  OrderRecord,
  OrderStatus,
  ProductCategory,
  ProductFormPayload,
  ProductItem,
  ProductSortOption,
  ShippingAddress,
} from '../types/store.ts';

const API_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

async function parseResponse<T>(response: Response): Promise<T> {
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error('Unexpected response format from server.');
  }
  const payload = await response.json();
  if (!response.ok) {
    const message =
      typeof payload?.message === 'string'
        ? payload.message
        : `Request failed with status ${response.status}`;
    const err = new Error(message) as Error & {
      status?: number;
      fieldErrors?: Record<string, string>;
    };
    err.status = response.status;
    if (payload?.errors && typeof payload.errors === 'object') {
      err.fieldErrors = payload.errors as Record<string, string>;
    }
    throw err;
  }
  return payload as T;
}

// ---------- Auth ----------

export async function fetchAdminStatus(): Promise<{
  adminClaimed: boolean;
  requiresSetupKey: boolean;
}> {
  const res = await fetch(`${API_BASE}/api/auth/admin-status`);
  return parseResponse<{success: boolean; adminClaimed: boolean; requiresSetupKey: boolean}>(res);
}

export async function bootstrapAdminAccount(input: {
  name: string;
  email: string;
  password: string;
  setupKey?: string;
}): Promise<AuthResponse> {
  const res = await fetch(`${API_BASE}/api/auth/bootstrap-admin`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json', Accept: 'application/json'},
    body: JSON.stringify(input),
  });
  return parseResponse<AuthResponse>(res);
}

export async function registerCustomer(input: {
  name: string;
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const res = await fetch(`${API_BASE}/api/auth/register`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json', Accept: 'application/json'},
    body: JSON.stringify(input),
  });
  return parseResponse<AuthResponse>(res);
}

export async function loginAccount(input: {
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const res = await fetch(`${API_BASE}/api/auth/login`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json', Accept: 'application/json'},
    body: JSON.stringify(input),
  });
  return parseResponse<AuthResponse>(res);
}

export async function logoutAccount(token: string): Promise<void> {
  await fetch(`${API_BASE}/api/auth/logout`, {
    method: 'POST',
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
}

export async function updateProfileName(token: string, name: string): Promise<AuthUser> {
  const res = await fetch(`${API_BASE}/api/auth/profile`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify({name}),
  });
  const data = await parseResponse<{success: boolean; user: AuthUser}>(res);
  return data.user;
}

// ---------- Products ----------

export async function fetchProducts(params: {
  category?: ProductCategory | 'All';
  search?: string;
  sort?: ProductSortOption;
} = {}): Promise<ProductItem[]> {
  const query = new URLSearchParams();
  if (params.category && params.category !== 'All') {
    query.set('category', params.category);
  }
  if (params.search && params.search.trim()) {
    query.set('search', params.search.trim());
  }
  if (params.sort) {
    query.set('sort', params.sort);
  }
  const qs = query.toString();
  const res = await fetch(`${API_BASE}/api/products${qs ? `?${qs}` : ''}`);
  const data = await parseResponse<{success: boolean; data: ProductItem[]}>(res);
  return data.data;
}

export async function fetchProductDetail(idOrSlug: string): Promise<ProductItem> {
  const res = await fetch(`${API_BASE}/api/products/${encodeURIComponent(idOrSlug)}`);
  const data = await parseResponse<{success: boolean; data: ProductItem}>(res);
  return data.data;
}

export async function createProductAdmin(
  token: string,
  payload: ProductFormPayload,
): Promise<ProductItem> {
  const res = await fetch(`${API_BASE}/api/products`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await parseResponse<{success: boolean; data: ProductItem}>(res);
  return data.data;
}

export async function updateProductAdmin(
  token: string,
  productId: string,
  payload: Partial<ProductFormPayload>,
): Promise<ProductItem> {
  const res = await fetch(`${API_BASE}/api/products/${encodeURIComponent(productId)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await parseResponse<{success: boolean; data: ProductItem}>(res);
  return data.data;
}

export async function deleteProductAdmin(token: string, productId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/products/${encodeURIComponent(productId)}`, {
    method: 'DELETE',
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
  await parseResponse<{success: boolean}>(res);
}

// ---------- Cart ----------

export async function fetchUserCart(token: string): Promise<CartLineItem[]> {
  const res = await fetch(`${API_BASE}/api/cart`, {
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
  const data = await parseResponse<{success: boolean; data: CartLineItem[]}>(res);
  return data.data;
}

export async function addToUserCart(
  token: string,
  productId: string,
  quantity: number,
): Promise<CartLineItem[]> {
  const res = await fetch(`${API_BASE}/api/cart`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify({productId, quantity}),
  });
  const data = await parseResponse<{success: boolean; data: CartLineItem[]}>(res);
  return data.data;
}

export async function mergeGuestCartApi(
  token: string,
  items: Array<{productId: string; quantity: number}>,
): Promise<CartLineItem[]> {
  const res = await fetch(`${API_BASE}/api/cart/merge`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify({items}),
  });
  const data = await parseResponse<{success: boolean; data: CartLineItem[]}>(res);
  return data.data;
}

export async function updateCartQtyApi(
  token: string,
  productId: string,
  quantity: number,
): Promise<CartLineItem[]> {
  const res = await fetch(`${API_BASE}/api/cart/${encodeURIComponent(productId)}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify({quantity}),
  });
  const data = await parseResponse<{success: boolean; data: CartLineItem[]}>(res);
  return data.data;
}

export async function removeCartItemApi(
  token: string,
  productId: string,
): Promise<CartLineItem[]> {
  const res = await fetch(`${API_BASE}/api/cart/${encodeURIComponent(productId)}`, {
    method: 'DELETE',
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
  const data = await parseResponse<{success: boolean; data: CartLineItem[]}>(res);
  return data.data;
}

// ---------- Orders ----------

export async function placeDemoOrder(
  token: string,
  payload: {
    items: Array<{productId: string; quantity: number}>;
    shippingAddress: ShippingAddress;
    paymentMethod: 'cod' | 'demo-invoice';
  },
): Promise<OrderRecord> {
  const res = await fetch(`${API_BASE}/api/orders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await parseResponse<{success: boolean; data: OrderRecord}>(res);
  return data.data;
}

export async function fetchMyOrders(token: string): Promise<OrderRecord[]> {
  const res = await fetch(`${API_BASE}/api/orders/mine`, {
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
  const data = await parseResponse<{success: boolean; data: OrderRecord[]}>(res);
  return data.data;
}

export async function fetchAllOrdersAdmin(token: string): Promise<OrderRecord[]> {
  const res = await fetch(`${API_BASE}/api/orders/all`, {
    headers: {Authorization: `Bearer ${token}`, Accept: 'application/json'},
  });
  const data = await parseResponse<{success: boolean; data: OrderRecord[]}>(res);
  return data.data;
}

export async function updateOrderStatusAdmin(
  token: string,
  orderId: string,
  status: OrderStatus,
): Promise<OrderRecord> {
  const res = await fetch(`${API_BASE}/api/orders/${encodeURIComponent(orderId)}/status`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify({status}),
  });
  const data = await parseResponse<{success: boolean; data: OrderRecord}>(res);
  return data.data;
}
