export type UserRole = 'customer' | 'admin';

export type ProductCategory = 'Keyboards' | 'Audio' | 'Lighting' | 'Accessories';

export type OrderStatus = 'Pending' | 'Processing' | 'Shipped' | 'Delivered';

export type ProductSortOption = 'featured' | 'price-asc' | 'price-desc';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt?: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token: string;
  user: AuthUser;
}

export interface ProductItem {
  id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  price: number;
  stock: number;
  description: string;
  specs: string[];
  imageUrl: string;
  featured: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ProductFormPayload {
  name: string;
  category: ProductCategory;
  price: number;
  stock: number;
  description: string;
  specs: string[];
  imageUrl: string;
  featured?: boolean;
}

export interface CartLineItem {
  productId: string;
  quantity: number;
  product: ProductItem;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  postalCode: string;
}

export interface OrderLineItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl: string;
}

export interface OrderRecord {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  items: OrderLineItem[];
  shippingAddress: ShippingAddress;
  paymentMethod: 'cod' | 'demo-invoice';
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}
