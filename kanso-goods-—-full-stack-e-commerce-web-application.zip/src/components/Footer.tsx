import {Moon, Sun} from 'lucide-react';
import type {ThemeMode} from '../hooks/useTheme.ts';

interface FooterProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  onNavigate: (path: string) => void;
}

export function Footer({theme, onToggleTheme, onNavigate}: FooterProps) {
  return (
    <footer className="border-t border-stone-200 bg-white py-10 transition-colors duration-200 dark:border-zinc-800 dark:bg-zinc-950">
      <div className="mx-auto flex max-w-6xl flex-col justify-between gap-6 px-4 sm:px-6 md:flex-row md:items-center lg:px-8">
        <div>
          <p className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">Kanso Goods</p>
          <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
            Full-Stack E-Commerce Project by Arun S · Easwari Engineering College, Chennai (CSE 2nd
            Year)
          </p>
        </div>

        <nav aria-label="Footer navigation" className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <button
            type="button"
            onClick={() => onNavigate('/products')}
            className="text-xs font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white"
          >
            Catalog
          </button>
          <button
            type="button"
            onClick={() => onNavigate('/cart')}
            className="text-xs font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white"
          >
            Shopping Bag
          </button>
          <button
            type="button"
            onClick={() => onNavigate('/orders')}
            className="text-xs font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white"
          >
            My Orders
          </button>
          <button
            type="button"
            onClick={onToggleTheme}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Light Theme</span>
              </>
            ) : (
              <>
                <Moon className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Dark Theme</span>
              </>
            )}
          </button>
        </nav>

        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          © {new Date().getFullYear()} Kanso Goods.
        </p>
      </div>
    </footer>
  );
}
