import {Check, Plus} from 'lucide-react';
import {useState} from 'react';
import type {ProductItem} from '../types/store.ts';
import {formatPrice} from '../utils/currency.ts';
import {MediaFrame} from './MediaFrame.tsx';

interface ProductCardProps {
  product: ProductItem;
  onViewDetails: (product: ProductItem) => void;
  onAddToCart: (product: ProductItem) => void;
}

export function ProductCard({product, onViewDetails, onAddToCart}: ProductCardProps) {
  const [justAdded, setJustAdded] = useState(false);
  const outOfStock = product.stock <= 0;

  const handleQuickAdd = () => {
    if (outOfStock) {
      return;
    }
    onAddToCart(product);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1200);
  };

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900/70">
      <button
        type="button"
        onClick={() => onViewDetails(product)}
        className="aspect-[4/3] w-full overflow-hidden bg-stone-100 text-left dark:bg-zinc-900"
      >
        <MediaFrame
          src={product.imageUrl}
          alt={product.name}
          fallbackTitle={product.name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </button>

      <div className="flex flex-1 flex-col justify-between p-5">
        <div>
          <div className="flex items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
            <span className="font-medium tracking-wide uppercase">{product.category}</span>
            <span
              className={
                outOfStock
                  ? 'font-medium text-red-600 dark:text-red-400'
                  : product.stock <= 5
                    ? 'font-medium text-amber-600 dark:text-amber-400'
                    : 'text-zinc-500 dark:text-zinc-400'
              }
            >
              {outOfStock
                ? 'Out of Stock'
                : product.stock <= 5
                  ? `Only ${product.stock} left`
                  : 'In Stock'}
            </span>
          </div>

          <button
            type="button"
            onClick={() => onViewDetails(product)}
            className="mt-2 block text-left text-base font-semibold leading-snug text-zinc-950 transition-colors hover:text-blue-600 dark:text-zinc-50 dark:hover:text-blue-400"
          >
            {product.name}
          </button>

          <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-zinc-600 dark:text-zinc-400">
            {product.description}
          </p>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-stone-200 pt-4 dark:border-zinc-800">
          <span className="font-mono text-base font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
            {formatPrice(product.price)}
          </span>

          <button
            type="button"
            disabled={outOfStock}
            onClick={handleQuickAdd}
            className={`inline-flex min-h-10 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors ${
              outOfStock
                ? 'cursor-not-allowed bg-stone-200 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-500'
                : justAdded
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-900 text-white hover:bg-blue-600 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Added</span>
              </>
            ) : (
              <>
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{outOfStock ? 'Unavailable' : 'Add to Bag'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
