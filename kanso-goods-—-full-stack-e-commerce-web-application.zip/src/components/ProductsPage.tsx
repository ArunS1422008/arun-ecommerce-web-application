import {RefreshCw, Search} from 'lucide-react';
import type {ProductCategory, ProductItem, ProductSortOption} from '../types/store.ts';
import {ProductCard} from './ProductCard.tsx';

interface ProductsPageProps {
  products: ProductItem[];
  loading: boolean;
  error: string | null;
  category: ProductCategory | 'All';
  search: string;
  sort: ProductSortOption;
  onChangeCategory: (category: ProductCategory | 'All') => void;
  onChangeSearch: (value: string) => void;
  onChangeSort: (sort: ProductSortOption) => void;
  onRetry: () => void;
  onViewDetails: (product: ProductItem) => void;
  onAddToCart: (product: ProductItem) => void;
}

const CATEGORIES: Array<ProductCategory | 'All'> = [
  'All',
  'Keyboards',
  'Audio',
  'Lighting',
  'Accessories',
];

export function ProductsPage({
  products,
  loading,
  error,
  category,
  search,
  sort,
  onChangeCategory,
  onChangeSearch,
  onChangeSort,
  onRetry,
  onViewDetails,
  onAddToCart,
}: ProductsPageProps) {
  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-4 border-b border-stone-200 pb-6 md:flex-row md:items-end dark:border-zinc-800">
          <div>
            <p className="text-xs font-semibold tracking-wider text-blue-600 uppercase dark:text-blue-400">
              Product Catalog
            </p>
            <h1 className="mt-1.5 text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
              All Studio Gear
            </h1>
          </div>

          <p className="font-mono text-xs tabular-nums text-zinc-500 dark:text-zinc-400">
            {products.length} {products.length === 1 ? 'item' : 'items'} shown
          </p>
        </div>

        {/* Search, Category & Sort Toolbar */}
        <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div
            role="group"
            aria-label="Filter by product category"
            className="inline-flex flex-wrap items-center gap-1 self-start rounded-lg border border-stone-200 bg-white p-1 dark:border-zinc-800 dark:bg-zinc-900"
          >
            {CATEGORIES.map((cat) => {
              const active = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => onChangeCategory(cat)}
                  aria-pressed={active}
                  className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                    active
                      ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950'
                      : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative min-w-[240px] flex-1">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400"
                aria-hidden="true"
              />
              <input
                type="search"
                value={search}
                onChange={(event) => onChangeSearch(event.target.value)}
                placeholder="Search products..."
                aria-label="Search products"
                className="block min-h-10 w-full rounded-lg border border-stone-300 bg-white py-2 pl-9 pr-3 text-sm text-zinc-950 placeholder:text-zinc-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:placeholder:text-zinc-500"
              />
            </div>

            <select
              aria-label="Sort products by price"
              value={sort}
              onChange={(event) => onChangeSort(event.target.value as ProductSortOption)}
              className="min-h-10 rounded-lg border border-stone-300 bg-white px-3 py-2 text-xs font-medium text-zinc-800 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2, 3, 4, 5].map((skeleton) => (
              <div
                key={skeleton}
                className="overflow-hidden rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900"
              >
                <div className="aspect-[4/3] animate-pulse bg-stone-200 dark:bg-zinc-800" />
                <div className="space-y-3 p-5">
                  <div className="h-3 w-20 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                  <div className="h-5 w-3/4 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                  <div className="h-9 w-full animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {!loading && error && (
          <div
            role="alert"
            className="mt-8 flex flex-col items-start justify-between gap-4 rounded-2xl border border-red-200 bg-red-50 p-6 sm:flex-row sm:items-center dark:border-red-900/60 dark:bg-red-950/30"
          >
            <div>
              <p className="text-sm font-semibold text-red-900 dark:text-red-200">
                Unable to load products
              </p>
              <p className="mt-1 text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
            <button
              type="button"
              onClick={onRetry}
              className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-red-700 px-4 py-2 text-xs font-semibold text-white hover:bg-red-800"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && products.length === 0 && (
          <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-12 text-center dark:border-zinc-800 dark:bg-zinc-900">
            <p className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
              No matching products found
            </p>
            <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-400">
              Try clearing your search term or selecting another category.
            </p>
            <button
              type="button"
              onClick={() => {
                onChangeCategory('All');
                onChangeSearch('');
              }}
              className="mt-5 inline-flex min-h-10 items-center rounded-lg bg-zinc-900 px-4 py-2 text-xs font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Product Grid */}
        {!loading && !error && products.length > 0 && (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
