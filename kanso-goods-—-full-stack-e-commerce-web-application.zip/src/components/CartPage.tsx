import {ArrowRight, Minus, Plus, ShoppingBag, Trash2} from 'lucide-react';
import type {CartLineItem} from '../types/store.ts';
import {
  FREE_SHIPPING_THRESHOLD,
  STANDARD_SHIPPING_FEE,
  formatPrice,
} from '../utils/currency.ts';
import {MediaFrame} from './MediaFrame.tsx';

interface CartPageProps {
  items: CartLineItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onContinueShopping: () => void;
  onCheckout: () => void;
}

export function CartPage({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onContinueShopping,
  onCheckout,
}: CartPageProps) {
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = items.length === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_FEE;
  const total = subtotal + shipping;

  if (items.length === 0) {
    return (
      <section className="py-16">
        <div className="mx-auto max-w-2xl px-4 text-center">
          <ShoppingBag
            className="mx-auto h-10 w-10 text-zinc-400 dark:text-zinc-600"
            aria-hidden="true"
          />
          <h1 className="mt-4 text-2xl font-semibold text-zinc-950 dark:text-zinc-50">
            Your shopping bag is empty
          </h1>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            Explore our catalog of keyboards, studio audio, lighting, and desk accessories to add
            items to your bag.
          </p>
          <button
            type="button"
            onClick={onContinueShopping}
            className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-lg bg-zinc-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-600 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white"
          >
            <span>Browse Products</span>
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
          Shopping Bag
        </h1>

        <div className="mt-8 grid items-start gap-8 lg:grid-cols-12">
          {/* Itemized Cart List */}
          <div className="divide-y divide-stone-200 rounded-2xl border border-stone-200 bg-white lg:col-span-8 dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/70">
            {items.map((item) => (
              <div
                key={item.productId}
                className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className="h-20 w-24 shrink-0 overflow-hidden rounded-xl border border-stone-200 bg-stone-100 dark:border-zinc-800 dark:bg-zinc-900">
                    <MediaFrame
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      fallbackTitle={item.product.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-zinc-500 uppercase dark:text-zinc-400">
                      {item.product.category}
                    </p>
                    <h2 className="mt-0.5 text-base font-semibold text-zinc-950 dark:text-zinc-50">
                      {item.product.name}
                    </h2>
                    <p className="mt-1 font-mono text-sm tabular-nums text-zinc-600 dark:text-zinc-300">
                      {formatPrice(item.product.price)} each
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-4 sm:justify-end">
                  <div className="inline-flex items-center rounded-lg border border-stone-300 bg-stone-50 dark:border-zinc-700 dark:bg-zinc-950">
                    <button
                      type="button"
                      onClick={() => onUpdateQuantity(item.productId, item.quantity - 1)}
                      aria-label={`Decrease quantity for ${item.product.name}`}
                      className="inline-flex h-9 w-9 items-center justify-center text-zinc-700 hover:bg-stone-200 dark:text-zinc-200 dark:hover:bg-zinc-800"
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-9 text-center font-mono text-sm font-semibold tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      disabled={item.quantity >= item.product.stock}
                      onClick={() => onUpdateQuantity(item.productId, item.quantity + 1)}
                      aria-label={`Increase quantity for ${item.product.name}`}
                      className="inline-flex h-9 w-9 items-center justify-center text-zinc-700 hover:bg-stone-200 disabled:opacity-40 dark:text-zinc-200 dark:hover:bg-zinc-800"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <p className="w-24 text-right font-mono text-sm font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
                    {formatPrice(item.product.price * item.quantity)}
                  </p>

                  <button
                    type="button"
                    onClick={() => onRemoveItem(item.productId)}
                    aria-label={`Remove ${item.product.name} from bag`}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-red-50 hover:text-red-600 dark:text-zinc-400 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Cart Summary */}
          <aside className="rounded-2xl border border-stone-200 bg-white p-6 lg:col-span-4 dark:border-zinc-800 dark:bg-zinc-900/70">
            <h2 className="text-lg font-semibold text-zinc-950 dark:text-zinc-50">Order Summary</h2>

            <dl className="mt-5 space-y-3 border-t border-stone-200 pt-4 text-sm dark:border-zinc-800">
              <div className="flex items-center justify-between">
                <dt className="text-zinc-600 dark:text-zinc-400">Subtotal</dt>
                <dd className="font-mono font-medium tabular-nums text-zinc-950 dark:text-zinc-100">
                  {formatPrice(subtotal)}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-zinc-600 dark:text-zinc-400">Shipping</dt>
                <dd className="font-mono font-medium tabular-nums text-zinc-950 dark:text-zinc-100">
                  {shipping === 0 ? 'Free' : formatPrice(shipping)}
                </dd>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Add {formatPrice(FREE_SHIPPING_THRESHOLD - subtotal)} more for free shipping.
                </p>
              )}
              <div className="flex items-center justify-between border-t border-stone-200 pt-3 text-base font-semibold dark:border-zinc-800">
                <dt className="text-zinc-950 dark:text-zinc-50">Total</dt>
                <dd className="font-mono tabular-nums text-zinc-950 dark:text-zinc-50">
                  {formatPrice(total)}
                </dd>
              </div>
            </dl>

            <button
              type="button"
              onClick={onCheckout}
              className="mt-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onContinueShopping}
              className="mt-3 inline-flex min-h-10 w-full items-center justify-center rounded-lg border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 hover:bg-stone-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
            >
              Continue Shopping
            </button>
          </aside>
        </div>
      </div>
    </section>
  );
}
