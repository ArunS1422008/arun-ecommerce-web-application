import {ArrowRight, PackageCheck, ShieldCheck, Truck} from 'lucide-react';
import {motion} from 'motion/react';
import type {ProductItem} from '../types/store.ts';
import {MediaFrame} from './MediaFrame.tsx';
import {ProductCard} from './ProductCard.tsx';

interface HomePageProps {
  featuredProducts: ProductItem[];
  loading: boolean;
  onNavigate: (path: string) => void;
  onAddToCart: (product: ProductItem) => void;
}

const HERO_IMAGE = '/src/assets/images/hero_studio_gear_1795477484726.jpg';

export function HomePage({
  featuredProducts,
  loading,
  onNavigate,
  onAddToCart,
}: HomePageProps) {
  return (
    <div>
      {/* Section 1: Storefront Hero */}
      <section className="border-b border-stone-200 bg-stone-50 py-12 sm:py-16 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-8 lg:grid-cols-12 lg:gap-12">
            <motion.div
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.35, ease: [0.16, 1, 0.3, 1]}}
              className="lg:col-span-5"
            >
              <p className="text-xs font-semibold tracking-wider text-blue-600 uppercase dark:text-blue-400">
                Studio Hardware &amp; Deskware
              </p>

              <h1
                className="mt-3 text-balance font-semibold tracking-tight text-zinc-950 dark:text-zinc-50"
                style={{fontSize: 'clamp(2.2rem, 4vw, 3.35rem)', lineHeight: 1.08}}
              >
                Tactile tools built for focused daily work.
              </h1>

              <p className="mt-5 text-base leading-relaxed text-zinc-600 dark:text-zinc-300">
                Precision-machined aluminum keyboards, reference headphones, architectural task
                lighting, and everyday studio essentials—engineered for durability and calm
                workspaces.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('/products')}
                  className="inline-flex min-h-11 items-center gap-2 whitespace-nowrap rounded-lg bg-zinc-900 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-600 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white"
                >
                  <span>Shop Collection</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('/orders')}
                  className="inline-flex min-h-11 items-center whitespace-nowrap rounded-lg border border-stone-300 bg-white px-5 py-3 text-sm font-semibold text-zinc-900 transition-colors hover:bg-stone-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800"
                >
                  Track Orders
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.4, delay: 0.05, ease: [0.16, 1, 0.3, 1]}}
              className="lg:col-span-7"
            >
              <div className="aspect-[16/9] overflow-hidden rounded-2xl border border-stone-200 bg-stone-100 dark:border-zinc-800 dark:bg-zinc-900">
                <MediaFrame
                  src={HERO_IMAGE}
                  alt="Kanso Goods curated studio desk featuring aluminum keyboard, headphones, and task lamp"
                  fallbackTitle="Kanso Goods Studio Collection"
                  className="h-full w-full object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section 2: Featured Collection */}
      <section className="border-b border-stone-200 bg-white py-14 sm:py-20 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold tracking-wider text-blue-600 uppercase dark:text-blue-400">
                Featured Selection
              </p>
              <h2 className="mt-2 text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
                Essential Desk Hardware
              </h2>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('/products')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              <span>View All Products</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          {loading ? (
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((idx) => (
                <div
                  key={idx}
                  className="overflow-hidden rounded-2xl border border-stone-200 bg-stone-50 dark:border-zinc-800 dark:bg-zinc-900"
                >
                  <div className="aspect-[4/3] animate-pulse bg-stone-200 dark:bg-zinc-800" />
                  <div className="space-y-3 p-5">
                    <div className="h-3 w-20 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                    <div className="h-5 w-3/4 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                    <div className="h-9 w-full animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {featuredProducts.slice(0, 3).map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onViewDetails={(p) => onNavigate(`/products/${p.slug}`)}
                  onAddToCart={onAddToCart}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Section 3: Craftsmanship & Store Guarantees */}
      <section className="bg-stone-50 py-14 sm:py-20 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="rounded-2xl border border-stone-200 bg-white p-6 dark:border-zinc-800 dark:bg-zinc-900/70">
              <Truck className="h-5 w-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              <h3 className="mt-4 text-base font-semibold text-zinc-950 dark:text-zinc-50">
                Free Delivery Over ₹2,999
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
                Orders above ₹2,999 ship free across India with live step-by-step order tracking
                from confirmation to delivery.
              </p>
            </div>

            <div className="rounded-2xl border border-stone-200 bg-white p-6 dark:border-zinc-800 dark:bg-zinc-900/70">
              <PackageCheck
                className="h-5 w-5 text-blue-600 dark:text-blue-400"
                aria-hidden="true"
              />
              <h3 className="mt-4 text-base font-semibold text-zinc-950 dark:text-zinc-50">
                Verified Live Inventory
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
                Stock levels update automatically in MongoDB whenever orders are placed or managed
                in the store admin console.
              </p>
            </div>

            <div className="rounded-2xl border border-stone-200 bg-white p-6 dark:border-zinc-800 dark:bg-zinc-900/70">
              <ShieldCheck
                className="h-5 w-5 text-blue-600 dark:text-blue-400"
                aria-hidden="true"
              />
              <h3 className="mt-4 text-base font-semibold text-zinc-950 dark:text-zinc-50">
                Safe Demo Checkout
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
                Supports Cash on Delivery (COD) and Demo Invoice confirmation without collecting or
                storing real payment card numbers.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
