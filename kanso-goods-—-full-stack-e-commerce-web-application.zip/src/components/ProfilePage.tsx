import {CheckCircle2, Loader2, LogOut, Package, Shield, User as UserIcon} from 'lucide-react';
import {useState, type FormEvent} from 'react';
import {updateProfileName} from '../services/api.ts';
import type {AuthUser} from '../types/store.ts';

interface ProfilePageProps {
  token: string;
  user: AuthUser;
  onUserUpdated: (user: AuthUser) => void;
  onNavigate: (path: string) => void;
  onLogout: () => void;
}

export function ProfilePage({
  token,
  user,
  onUserUpdated,
  onNavigate,
  onLogout,
}: ProfilePageProps) {
  const [name, setName] = useState(user.name);
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  const handleSave = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSavedNotice(null);
    setErrorNotice(null);
    if (name.trim().length < 2) {
      setErrorNotice('Display name must be at least 2 characters.');
      return;
    }
    setSaving(true);
    try {
      const updated = await updateProfileName(token, name.trim());
      onUserUpdated(updated);
      setSavedNotice('Profile name updated.');
    } catch (err) {
      setErrorNotice(err instanceof Error ? err.message : 'Unable to update profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
          Account Profile
        </h1>

        <div className="mt-6 rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900/70">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-6 dark:border-zinc-800">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950">
                <UserIcon className="h-5 w-5" aria-hidden="true" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-zinc-950 dark:text-zinc-50">
                  {user.name}
                </h2>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">
                  <span>{user.email}</span>
                  <span aria-hidden="true" className="mx-2">
                    ·
                  </span>
                  <span className="font-medium capitalize">{user.role}</span>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onLogout}
              className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 hover:bg-stone-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
            >
              <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Sign Out</span>
            </button>
          </div>

          <form onSubmit={handleSave} className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="profile-name"
                className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
              >
                Display Name
              </label>
              <div className="mt-1.5 flex flex-col gap-3 sm:flex-row">
                <input
                  id="profile-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="block flex-1 rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-zinc-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-600 disabled:opacity-60 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <span>Save Name</span>}
                </button>
              </div>
            </div>

            {savedNotice && (
              <p className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" />
                <span>{savedNotice}</span>
              </p>
            )}
            {errorNotice && (
              <p className="text-xs font-medium text-red-600 dark:text-red-400">{errorNotice}</p>
            )}
          </form>

          <div className="mt-8 grid gap-4 border-t border-stone-200 pt-6 sm:grid-cols-2 dark:border-zinc-800">
            <button
              type="button"
              onClick={() => onNavigate('/orders')}
              className="flex items-center justify-between rounded-xl border border-stone-200 bg-stone-50 p-4 text-left transition-colors hover:bg-stone-100 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-800"
            >
              <div>
                <p className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">My Orders</p>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  Track status and view past order receipts
                </p>
              </div>
              <Package className="h-5 w-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
            </button>

            {user.role === 'admin' && (
              <button
                type="button"
                onClick={() => onNavigate('/admin')}
                className="flex items-center justify-between rounded-xl border border-stone-200 bg-stone-50 p-4 text-left transition-colors hover:bg-stone-100 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-800"
              >
                <div>
                  <p className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
                    Admin Dashboard
                  </p>
                  <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                    Manage product inventory and customer orders
                  </p>
                </div>
                <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
