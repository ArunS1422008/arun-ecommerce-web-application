import {AlertCircle, Eye, EyeOff, Loader2, Shield} from 'lucide-react';
import {useEffect, useState, type FormEvent} from 'react';
import {
  bootstrapAdminAccount,
  fetchAdminStatus,
  loginAccount,
  registerCustomer,
} from '../services/api.ts';
import type {AuthUser} from '../types/store.ts';

interface AuthPagesProps {
  mode: 'login' | 'register';
  onSwitchMode: (mode: 'login' | 'register') => void;
  onAuthenticated: (token: string, user: AuthUser) => void;
}

export function AuthPages({mode, onSwitchMode, onAuthenticated}: AuthPagesProps) {
  const [adminClaimed, setAdminClaimed] = useState<boolean>(true);
  const [requiresSetupKey, setRequiresSetupKey] = useState<boolean>(false);
  const [claimAdminMode, setClaimAdminMode] = useState(false);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [setupKey, setSetupKey] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    let active = true;
    fetchAdminStatus()
      .then((res) => {
        if (active) {
          setAdminClaimed(res.adminClaimed);
          setRequiresSetupKey(res.requiresSetupKey);
        }
      })
      .catch(() => {
        // Non-fatal
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    setErrorMessage(null);
    setFieldErrors({});
  }, [mode, claimAdminMode]);

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if ((mode === 'register' || claimAdminMode) && name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    if (password.length < (mode === 'register' || claimAdminMode ? 6 : 1)) {
      errors.password =
        mode === 'register' || claimAdminMode
          ? 'Password must be at least 6 characters.'
          : 'Please enter your password.';
    }
    if (claimAdminMode && requiresSetupKey && !setupKey.trim()) {
      errors.setupKey = 'Admin setup key is required.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage(null);
    if (!validate()) return;

    setSubmitting(true);
    try {
      if (claimAdminMode) {
        const res = await bootstrapAdminAccount({
          name: name.trim(),
          email: email.trim(),
          password,
          ...(requiresSetupKey ? {setupKey: setupKey.trim()} : {}),
        });
        onAuthenticated(res.token, res.user);
      } else if (mode === 'register') {
        const res = await registerCustomer({
          name: name.trim(),
          email: email.trim(),
          password,
        });
        onAuthenticated(res.token, res.user);
      } else {
        const res = await loginAccount({
          email: email.trim(),
          password,
        });
        onAuthenticated(res.token, res.user);
      }
    } catch (error) {
      const typed = error as Error & {fieldErrors?: Record<string, string>};
      if (typed.fieldErrors) setFieldErrors(typed.fieldErrors);
      setErrorMessage(typed.message || 'Authentication failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const headingTitle = claimAdminMode
    ? 'Claim Store Admin Account'
    : mode === 'register'
      ? 'Create Customer Account'
      : 'Sign In to Kanso Goods';

  const headingSubtitle = claimAdminMode
    ? 'First-run setup: create the primary store administrator account. This locks once claimed.'
    : mode === 'register'
      ? 'Register to save your shopping bag, place orders, and track shipments.'
      : 'Access your saved shopping bag, order history, and account profile.';

  return (
    <section className="py-12 sm:py-16">
      <div className="mx-auto max-w-md px-4">
        <div className="rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900">
          {!claimAdminMode && (
            <div className="grid grid-cols-2 gap-1 rounded-lg border border-stone-200 bg-stone-100 p-1 dark:border-zinc-800 dark:bg-zinc-950">
              <button
                type="button"
                onClick={() => onSwitchMode('login')}
                className={`rounded-md py-2 text-sm font-semibold transition-colors ${
                  mode === 'login'
                    ? 'bg-white text-zinc-950 shadow-sm dark:bg-zinc-800 dark:text-white'
                    : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => onSwitchMode('register')}
                className={`rounded-md py-2 text-sm font-semibold transition-colors ${
                  mode === 'register'
                    ? 'bg-white text-zinc-950 shadow-sm dark:bg-zinc-800 dark:text-white'
                    : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white'
                }`}
              >
                Register
              </button>
            </div>
          )}

          <div className="mt-6">
            <h1 className="text-xl font-semibold text-zinc-950 dark:text-zinc-50">{headingTitle}</h1>
            <p className="mt-1.5 text-sm text-zinc-600 dark:text-zinc-400">{headingSubtitle}</p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
            {(mode === 'register' || claimAdminMode) && (
              <div>
                <label
                  htmlFor="auth-full-name"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  Full Name
                </label>
                <input
                  id="auth-full-name"
                  type="text"
                  autoComplete="name"
                  required
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (fieldErrors.name) setFieldErrors((p) => ({...p, name: ''}));
                  }}
                  placeholder="Arun S"
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.name && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.name}
                  </p>
                )}
              </div>
            )}

            <div>
              <label
                htmlFor="auth-email"
                className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
              >
                Email Address
              </label>
              <input
                id="auth-email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (fieldErrors.email) setFieldErrors((p) => ({...p, email: ''}));
                }}
                placeholder="you@example.com"
                className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
              />
              {fieldErrors.email && (
                <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                  {fieldErrors.email}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="auth-pass"
                className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
              >
                Password
              </label>
              <div className="relative mt-1.5">
                <input
                  id="auth-pass"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={mode === 'login' && !claimAdminMode ? 'current-password' : 'new-password'}
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (fieldErrors.password) setFieldErrors((p) => ({...p, password: ''}));
                  }}
                  placeholder={
                    mode === 'register' || claimAdminMode
                      ? 'Minimum 6 characters'
                      : 'Enter your password'
                  }
                  className="block w-full rounded-lg border border-stone-300 bg-white py-2.5 pl-3.5 pr-11 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {fieldErrors.password && (
                <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                  {fieldErrors.password}
                </p>
              )}
            </div>

            {claimAdminMode && requiresSetupKey && (
              <div>
                <label
                  htmlFor="admin-setup-key"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  Admin Setup Passcode
                </label>
                <input
                  id="admin-setup-key"
                  type="password"
                  required
                  value={setupKey}
                  onChange={(e) => setSetupKey(e.target.value)}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.setupKey && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.setupKey}
                  </p>
                )}
              </div>
            )}

            {errorMessage && (
              <div
                role="alert"
                className="flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200"
              >
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  <span>Please wait...</span>
                </>
              ) : (
                <span>
                  {claimAdminMode
                    ? 'Claim Admin Account'
                    : mode === 'register'
                      ? 'Create Account'
                      : 'Sign In'}
                </span>
              )}
            </button>
          </form>

          {!adminClaimed && (
            <div className="mt-6 border-t border-stone-200 pt-4 text-center dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setClaimAdminMode((prev) => !prev)}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 underline-offset-4 hover:text-zinc-950 hover:underline dark:text-zinc-400 dark:hover:text-white"
              >
                <Shield className="h-3.5 w-3.5" aria-hidden="true" />
                <span>
                  {claimAdminMode
                    ? 'Back to Customer Sign In'
                    : 'First-Run Setup: Claim Store Admin Account'}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
