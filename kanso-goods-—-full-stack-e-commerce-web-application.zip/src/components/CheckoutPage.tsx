import {AlertCircle, CheckCircle2, Info, Loader2, Lock} from 'lucide-react';
import {useState, type FormEvent} from 'react';
import {placeDemoOrder} from '../services/api.ts';
import type {AuthUser, CartLineItem, OrderRecord, ShippingAddress} from '../types/store.ts';
import {
  FREE_SHIPPING_THRESHOLD,
  STANDARD_SHIPPING_FEE,
  formatPrice,
} from '../utils/currency.ts';

interface CheckoutPageProps {
  token: string | null;
  user: AuthUser | null;
  items: CartLineItem[];
  onRequireLogin: () => void;
  onOrderPlaced: (order: OrderRecord) => void;
  onBackToCart: () => void;
}

export function CheckoutPage({
  token,
  user,
  items,
  onRequireLogin,
  onOrderPlaced,
  onBackToCart,
}: CheckoutPageProps) {
  const [address, setAddress] = useState<ShippingAddress>({
    fullName: user?.name || '',
    phone: '',
    street: '',
    city: '',
    state: '',
    postalCode: '',
  });
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'demo-invoice'>('cod');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  if (!token || !user) {
    return (
      <section className="py-16">
        <div className="mx-auto max-w-md rounded-2xl border border-stone-200 bg-white p-8 text-center dark:border-zinc-800 dark:bg-zinc-900">
          <Lock className="mx-auto h-8 w-8 text-blue-600 dark:text-blue-400" aria-hidden="true" />
          <h1 className="mt-4 text-xl font-semibold text-zinc-950 dark:text-zinc-50">
            Sign in required for checkout
          </h1>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            Sign in or create an account to save your shipping details and track your order status.
            Your bag items will stay preserved.
          </p>
          <button
            type="button"
            onClick={onRequireLogin}
            className="mt-6 inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700"
          >
            Sign In / Register to Continue
          </button>
        </div>
      </section>
    );
  }

  if (items.length === 0) {
    return (
      <section className="py-16">
        <div className="mx-auto max-w-md rounded-2xl border border-stone-200 bg-white p-8 text-center dark:border-zinc-800 dark:bg-zinc-900">
          <h1 className="text-xl font-semibold text-zinc-950 dark:text-zinc-50">
            No items ready for checkout
          </h1>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            Your shopping bag is currently empty.
          </p>
          <button
            type="button"
            onClick={onBackToCart}
            className="mt-6 inline-flex min-h-10 items-center justify-center rounded-lg bg-zinc-900 px-5 py-2 text-sm font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
          >
            Return to Bag
          </button>
        </div>
      </section>
    );
  }

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingFee = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_FEE;
  const totalAmount = subtotal + shippingFee;

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (address.fullName.trim().length < 2) errors.fullName = 'Full name is required.';
    if (!/^[0-9+\-\s()]{7,20}$/.test(address.phone.trim()))
      errors.phone = 'Enter a valid phone number.';
    if (address.street.trim().length < 5) errors.street = 'Enter your full street address.';
    if (address.city.trim().length < 2) errors.city = 'City is required.';
    if (address.state.trim().length < 2) errors.state = 'State is required.';
    if (!/^[A-Za-z0-9\-\s]{4,12}$/.test(address.postalCode.trim()))
      errors.postalCode = 'Enter a valid postal code.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage(null);
    if (!validate()) return;

    setSubmitting(true);
    try {
      const order = await placeDemoOrder(token, {
        items: items.map((i) => ({productId: i.productId, quantity: i.quantity})),
        shippingAddress: {
          fullName: address.fullName.trim(),
          phone: address.phone.trim(),
          street: address.street.trim(),
          city: address.city.trim(),
          state: address.state.trim(),
          postalCode: address.postalCode.trim(),
        },
        paymentMethod,
      });
      onOrderPlaced(order);
    } catch (error) {
      const typed = error as Error & {fieldErrors?: Record<string, string>};
      if (typed.fieldErrors) setFieldErrors(typed.fieldErrors);
      setErrorMessage(typed.message || 'Could not place order. Please review your details.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
          Checkout
        </h1>

        <div className="mt-4 flex items-start gap-3 rounded-xl border border-blue-200 bg-blue-50 p-4 text-xs leading-relaxed text-blue-900 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-blue-200">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-600 dark:text-blue-400" />
          <span>
            <strong>Safe Demo Checkout:</strong> This storefront uses Cash on Delivery (COD) and
            simulated order confirmation. Do not enter real bank or credit card numbers.
          </span>
        </div>

        <form onSubmit={handleSubmit} noValidate className="mt-8 grid items-start gap-8 lg:grid-cols-12">
          {/* Customer & Shipping Form */}
          <div className="space-y-6 rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 lg:col-span-7 dark:border-zinc-800 dark:bg-zinc-900/70">
            <div>
              <h2 className="text-lg font-semibold text-zinc-950 dark:text-zinc-50">
                Customer &amp; Shipping Details
              </h2>
              <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                Signed in as {user.email}
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="chk-name"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  Recipient Full Name
                </label>
                <input
                  id="chk-name"
                  type="text"
                  required
                  value={address.fullName}
                  onChange={(e) => {
                    setAddress((p) => ({...p, fullName: e.target.value}));
                    if (fieldErrors.fullName) setFieldErrors((p) => ({...p, fullName: ''}));
                  }}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.fullName && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.fullName}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="chk-phone"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  Phone Number
                </label>
                <input
                  id="chk-phone"
                  type="tel"
                  required
                  placeholder="+91 98765 43210"
                  value={address.phone}
                  onChange={(e) => {
                    setAddress((p) => ({...p, phone: e.target.value}));
                    if (fieldErrors.phone) setFieldErrors((p) => ({...p, phone: ''}));
                  }}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.phone && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.phone}
                  </p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="chk-street"
                className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
              >
                Street Address
              </label>
              <input
                id="chk-street"
                type="text"
                required
                placeholder="House No, Street Name, Area"
                value={address.street}
                onChange={(e) => {
                  setAddress((p) => ({...p, street: e.target.value}));
                  if (fieldErrors.street) setFieldErrors((p) => ({...p, street: ''}));
                }}
                className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
              />
              {fieldErrors.street && (
                <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                  {fieldErrors.street}
                </p>
              )}
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label
                  htmlFor="chk-city"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  City
                </label>
                <input
                  id="chk-city"
                  type="text"
                  required
                  placeholder="Chennai"
                  value={address.city}
                  onChange={(e) => {
                    setAddress((p) => ({...p, city: e.target.value}));
                    if (fieldErrors.city) setFieldErrors((p) => ({...p, city: ''}));
                  }}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.city && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.city}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="chk-state"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  State
                </label>
                <input
                  id="chk-state"
                  type="text"
                  required
                  placeholder="Tamil Nadu"
                  value={address.state}
                  onChange={(e) => {
                    setAddress((p) => ({...p, state: e.target.value}));
                    if (fieldErrors.state) setFieldErrors((p) => ({...p, state: ''}));
                  }}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.state && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.state}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="chk-postal"
                  className="block text-sm font-medium text-zinc-900 dark:text-zinc-100"
                >
                  Postal Code
                </label>
                <input
                  id="chk-postal"
                  type="text"
                  required
                  placeholder="600089"
                  value={address.postalCode}
                  onChange={(e) => {
                    setAddress((p) => ({...p, postalCode: e.target.value}));
                    if (fieldErrors.postalCode) setFieldErrors((p) => ({...p, postalCode: ''}));
                  }}
                  className="mt-1.5 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 font-mono text-sm tabular-nums text-zinc-950 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {fieldErrors.postalCode && (
                  <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                    {fieldErrors.postalCode}
                  </p>
                )}
              </div>
            </div>

            <div className="border-t border-stone-200 pt-5 dark:border-zinc-800">
              <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                Payment Verification Method (Demo)
              </p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label
                  className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3.5 text-sm ${
                    paymentMethod === 'cod'
                      ? 'border-blue-600 bg-blue-50/50 dark:border-blue-500 dark:bg-blue-950/20'
                      : 'border-stone-200 dark:border-zinc-800'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                  />
                  <span className="font-medium">Cash on Delivery (COD)</span>
                </label>

                <label
                  className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3.5 text-sm ${
                    paymentMethod === 'demo-invoice'
                      ? 'border-blue-600 bg-blue-50/50 dark:border-blue-500 dark:bg-blue-950/20'
                      : 'border-stone-200 dark:border-zinc-800'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'demo-invoice'}
                    onChange={() => setPaymentMethod('demo-invoice')}
                  />
                  <span className="font-medium">Demo Order Confirmation</span>
                </label>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <aside className="rounded-2xl border border-stone-200 bg-white p-6 lg:col-span-5 dark:border-zinc-800 dark:bg-zinc-900/70">
            <h2 className="text-lg font-semibold text-zinc-950 dark:text-zinc-50">Order Summary</h2>

            <ul className="mt-4 divide-y divide-stone-200 border-t border-stone-200 dark:divide-zinc-800 dark:border-zinc-800">
              {items.map((item) => (
                <li key={item.productId} className="flex items-center justify-between gap-3 py-3 text-sm">
                  <div className="min-w-0">
                    <p className="truncate font-medium text-zinc-900 dark:text-zinc-100">
                      {item.product.name}
                    </p>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      Qty {item.quantity} × {formatPrice(item.product.price)}
                    </p>
                  </div>
                  <span className="shrink-0 font-mono font-medium tabular-nums text-zinc-950 dark:text-zinc-100">
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </li>
              ))}
            </ul>

            <dl className="mt-4 space-y-2.5 border-t border-stone-200 pt-4 text-sm dark:border-zinc-800">
              <div className="flex items-center justify-between">
                <dt className="text-zinc-600 dark:text-zinc-400">Subtotal</dt>
                <dd className="font-mono font-medium tabular-nums">{formatPrice(subtotal)}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-zinc-600 dark:text-zinc-400">Shipping</dt>
                <dd className="font-mono font-medium tabular-nums">
                  {shippingFee === 0 ? 'Free' : formatPrice(shippingFee)}
                </dd>
              </div>
              <div className="flex items-center justify-between border-t border-stone-200 pt-3 text-base font-semibold dark:border-zinc-800">
                <dt>Total Amount</dt>
                <dd className="font-mono tabular-nums">{formatPrice(totalAmount)}</dd>
              </div>
            </dl>

            {errorMessage && (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200"
              >
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="mt-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  <span>Confirming Order...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>Place Demo Order</span>
                </>
              )}
            </button>
          </aside>
        </form>
      </div>
    </section>
  );
}
