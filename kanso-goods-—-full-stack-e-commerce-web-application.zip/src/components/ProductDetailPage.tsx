import {ArrowLeft, Check, Minus, Plus, ShoppingBag} from 'lucide-react';
import {useEffect, useState} from 'react';
import {fetchProductDetail} from '../services/api.ts';
import type {ProductItem} from '../types/store.ts';
import {formatPrice} from '../utils/currency.ts';
import {MediaFrame} from './MediaFrame.tsx';

interface ProductDetailPageProps {
  slugOrId: string;
  onBack: () => void;
  onAddToCart: (product: ProductItem, quantity: number) => void;
  onGoToCart: () => void;
}

export function ProductDetailPage({
  slugOrId,
  onBack,
  onAddToCart,
  onGoToCart,
}: ProductDetailPageProps) {
  const [product, setProduct] = useState<ProductItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [addedBanner, setAddedBanner] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    fetchProductDetail(slugOrId)
      .then((item) => {
        if (active) {
          setProduct(item);
          setQuantity(1);
        }
      })
      .catch((err) => {
        if (active) {
          setError(err instanceof Error ? err.message : 'Unable to load product.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [slugOrId]);

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="aspect-[4/3] animate-pulse rounded-2xl bg-stone-200 lg:col-span-7 dark:bg-zinc-800" />
          <div className="space-y-4 lg:col-span-5">
            <div className="h-4 w-24 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
            <div className="h-8 w-3/4 animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
            <div className="h-24 w-full animate-pulse rounded bg-stone-200 dark:bg-zinc-800" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-xl font-semibold text-zinc-950 dark:text-zinc-50">
          Product Unavailable
        </h1>
        <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
          {error || 'The requested product could not be found.'}
        </p>
        <button
          type="button"
          onClick={onBack}
          className="mt-6 inline-flex min-h-10 items-center gap-2 rounded-lg bg-zinc-900 px-4 py-2 text-sm font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Catalog</span>
        </button>
      </div>
    );
  }

  const outOfStock = product.stock <= 0;

  const handleAdd = () => {
    if (outOfStock) return;
    onAddToCart(product, quantity);
    setAddedBanner(true);
    window.setTimeout(() => setAddedBanner(false), 2500);
  };

  return (
    <section className="pb-24 pt-8 sm:py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to Shop</span>
        </button>

        <div className="mt-6 grid items-start gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left: Product Gallery */}
          <div className="lg:sticky lg:top-24 lg:col-span-7">
            <div className="aspect-[4/3] overflow-hidden rounded-2xl border border-stone-200 bg-stone-100 dark:border-zinc-800 dark:bg-zinc-900">
              <MediaFrame
                src={product.imageUrl}
                alt={product.name}
                fallbackTitle={product.name}
                className="h-full w-full object-cover"
              />
            </div>
          </div>

          {/* Right: Contiguous Purchase Module */}
          <div className="rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 lg:sticky lg:top-24 lg:col-span-5 dark:border-zinc-800 dark:bg-zinc-900/70">
            <div className="flex items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
              <span className="font-semibold tracking-wider uppercase">{product.category}</span>
              <span
                className={`font-medium ${
                  outOfStock
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-emerald-700 dark:text-emerald-400'
                }`}
              >
                {outOfStock ? 'Out of Stock' : `${product.stock} units available`}
              </span>
            </div>

            <h1 className="mt-2 text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
              {product.name}
            </h1>

            <p className="mt-3 font-mono text-2xl font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
              {formatPrice(product.price)}
            </p>

            <p className="mt-4 text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
              {product.description}
            </p>

            {product.specs.length > 0 && (
              <div className="mt-6 border-t border-stone-200 pt-5 dark:border-zinc-800">
                <h2 className="text-xs font-semibold tracking-wider text-zinc-500 uppercase dark:text-zinc-400">
                  Specifications
                </h2>
                <ul className="mt-3 space-y-2 text-sm text-zinc-700 dark:text-zinc-300">
                  {product.specs.map((spec) => (
                    <li key={spec} className="flex items-start gap-2">
                      <span
                        aria-hidden="true"
                        className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-600 dark:bg-blue-400"
                      />
                      <span>{spec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Quantity & Add to Bag */}
            <div className="mt-6 space-y-3 border-t border-stone-200 pt-6 dark:border-zinc-800">
              <div className="flex items-center justify-between gap-4">
                <span className="text-sm font-medium text-zinc-800 dark:text-zinc-200">
                  Quantity
                </span>
                <div className="inline-flex items-center rounded-lg border border-stone-300 bg-stone-50 dark:border-zinc-700 dark:bg-zinc-950">
                  <button
                    type="button"
                    disabled={outOfStock || quantity <= 1}
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease quantity"
                    className="inline-flex h-10 w-10 items-center justify-center text-zinc-700 hover:bg-stone-200 disabled:opacity-40 dark:text-zinc-200 dark:hover:bg-zinc-800"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="w-10 text-center font-mono text-sm font-semibold tabular-nums">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    disabled={outOfStock || quantity >= product.stock}
                    onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                    aria-label="Increase quantity"
                    className="inline-flex h-10 w-10 items-center justify-center text-zinc-700 hover:bg-stone-200 disabled:opacity-40 dark:text-zinc-200 dark:hover:bg-zinc-800"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <button
                type="button"
                disabled={outOfStock}
                onClick={handleAdd}
                className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-zinc-900 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-600 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white"
              >
                {addedBanner ? (
                  <>
                    <Check className="h-4 w-4" />
                    <span>Added to Shopping Bag</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="h-4 w-4" />
                    <span>{outOfStock ? 'Currently Out of Stock' : 'Add to Shopping Bag'}</span>
                  </>
                )}
              </button>

              {addedBanner && (
                <button
                  type="button"
                  onClick={onGoToCart}
                  className="inline-flex min-h-10 w-full items-center justify-center rounded-lg border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-900 hover:bg-stone-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800"
                >
                  View Bag &amp; Checkout
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Sticky mobile bottom buy bar */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex items-center justify-between gap-4 border-t border-stone-200 bg-white/95 px-4 py-3 backdrop-blur-md md:hidden dark:border-zinc-800 dark:bg-zinc-950/95">
        <div>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">{product.name}</p>
          <p className="font-mono text-base font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
            {formatPrice(product.price)}
          </p>
        </div>
        <button
          type="button"
          disabled={outOfStock}
          onClick={handleAdd}
          className="inline-flex min-h-10 shrink-0 items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white disabled:opacity-50"
        >
          <ShoppingBag className="h-3.5 w-3.5" />
          <span>{outOfStock ? 'Out of Stock' : 'Add to Bag'}</span>
        </button>
      </div>
    </section>
  );
}
