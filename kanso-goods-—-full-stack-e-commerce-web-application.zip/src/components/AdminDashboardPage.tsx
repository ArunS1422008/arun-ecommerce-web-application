import {
  AlertCircle,
  CheckCircle2,
  Edit3,
  Loader2,
  Plus,
  ShieldAlert,
  Trash2,
  X,
} from 'lucide-react';
import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {
  createProductAdmin,
  deleteProductAdmin,
  fetchAllOrdersAdmin,
  updateOrderStatusAdmin,
  updateProductAdmin,
} from '../services/api.ts';
import type {
  AuthUser,
  OrderRecord,
  OrderStatus,
  ProductCategory,
  ProductFormPayload,
  ProductItem,
} from '../types/store.ts';
import {formatPrice} from '../utils/currency.ts';
import {MediaFrame} from './MediaFrame.tsx';

interface AdminDashboardPageProps {
  token: string;
  user: AuthUser;
  products: ProductItem[];
  onRefreshProducts: () => Promise<void>;
}

const STUDIO_IMAGE_PRESETS = [
  {
    label: 'Aluminum Keyboard',
    url: '/src/assets/images/product_mech_keyboard_1795477485526.jpg',
  },
  {
    label: 'Studio Headphones',
    url: '/src/assets/images/product_studio_headphones_1795477484901.jpg',
  },
  {
    label: 'Architectural Desk Lamp',
    url: '/src/assets/images/product_desk_lamp_1795477484828.jpg',
  },
  {
    label: 'USB-C Workstation Dock',
    url: '/src/assets/images/product_usbc_dock_1795477485806.jpg',
  },
  {
    label: 'Leather Sleeve & Stylus',
    url: '/src/assets/images/product_leather_sleeve_1795477486275.jpg',
  },
  {
    label: 'Stoneware Desk Tumbler',
    url: '/src/assets/images/product_ceramic_mug_1795477486450.jpg',
  },
];

const ORDER_STATUSES: OrderStatus[] = ['Pending', 'Processing', 'Shipped', 'Delivered'];

export function AdminDashboardPage({
  token,
  user,
  products,
  onRefreshProducts,
}: AdminDashboardPageProps) {
  const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [feedback, setFeedback] = useState<{type: 'success' | 'error'; text: string} | null>(null);

  // Product Form Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);
  const [formState, setFormState] = useState<ProductFormPayload>({
    name: '',
    category: 'Keyboards',
    price: 2990,
    stock: 10,
    description: '',
    specs: [],
    imageUrl: STUDIO_IMAGE_PRESETS[0].url,
    featured: false,
  });
  const [specsText, setSpecsText] = useState('');
  const [savingProduct, setSavingProduct] = useState(false);

  // Delete confirmation state
  const [deletingProduct, setDeletingProduct] = useState<ProductItem | null>(null);
  const [deletingInFlight, setDeletingInFlight] = useState(false);

  const loadOrders = useCallback(async () => {
    setOrdersLoading(true);
    try {
      const data = await fetchAllOrdersAdmin(token);
      setOrders(data);
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to load customer orders.',
      });
    } finally {
      setOrdersLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (user.role === 'admin' && activeTab === 'orders') {
      void loadOrders();
    }
  }, [user.role, activeTab, loadOrders]);

  if (user.role !== 'admin') {
    return (
      <section className="py-16">
        <div className="mx-auto max-w-md rounded-2xl border border-red-200 bg-white p-8 text-center dark:border-red-900/60 dark:bg-zinc-900">
          <ShieldAlert className="mx-auto h-9 w-9 text-red-600 dark:text-red-400" />
          <h1 className="mt-4 text-xl font-semibold text-zinc-950 dark:text-zinc-50">
            Admin Access Restricted
          </h1>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            Your account has the Customer role. Only Store Administrators can manage products,
            inventory, and customer order statuses.
          </p>
        </div>
      </section>
    );
  }

  const openCreateModal = () => {
    setEditingProduct(null);
    setFormState({
      name: '',
      category: 'Keyboards',
      price: 2990,
      stock: 10,
      description: '',
      specs: [],
      imageUrl: STUDIO_IMAGE_PRESETS[0].url,
      featured: false,
    });
    setSpecsText('');
    setModalOpen(true);
  };

  const openEditModal = (product: ProductItem) => {
    setEditingProduct(product);
    setFormState({
      name: product.name,
      category: product.category,
      price: product.price,
      stock: product.stock,
      description: product.description,
      specs: product.specs,
      imageUrl: product.imageUrl,
      featured: product.featured,
    });
    setSpecsText(product.specs.join('\n'));
    setModalOpen(true);
  };

  const handleSaveProduct = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSavingProduct(true);
    setFeedback(null);

    const payload: ProductFormPayload = {
      ...formState,
      price: Number(formState.price),
      stock: Number(formState.stock),
      specs: specsText
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean),
    };

    try {
      if (editingProduct) {
        await updateProductAdmin(token, editingProduct.id, payload);
        setFeedback({type: 'success', text: `Updated "${payload.name}".`});
      } else {
        await createProductAdmin(token, payload);
        setFeedback({type: 'success', text: `Added "${payload.name}" to catalog.`});
      }
      await onRefreshProducts();
      setModalOpen(false);
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to save product.',
      });
    } finally {
      setSavingProduct(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingProduct) return;
    setDeletingInFlight(true);
    try {
      await deleteProductAdmin(token, deletingProduct.id);
      setFeedback({type: 'success', text: `Removed "${deletingProduct.name}".`});
      await onRefreshProducts();
      setDeletingProduct(null);
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to delete product.',
      });
    } finally {
      setDeletingInFlight(false);
    }
  };

  const handleOrderStatusChange = async (orderId: string, nextStatus: OrderStatus) => {
    try {
      const updated = await updateOrderStatusAdmin(token, orderId, nextStatus);
      setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setFeedback({
        type: 'success',
        text: `Order ${updated.orderNumber} status updated to ${updated.status}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to update order status.',
      });
    }
  };

  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-4 border-b border-stone-200 pb-6 sm:flex-row sm:items-center dark:border-zinc-800">
          <div>
            <p className="text-xs font-semibold tracking-wider text-blue-600 uppercase dark:text-blue-400">
              Admin Console
            </p>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
              Inventory &amp; Order Management
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="inline-flex rounded-lg border border-stone-200 bg-white p-1 dark:border-zinc-800 dark:bg-zinc-900">
              <button
                type="button"
                onClick={() => setActiveTab('products')}
                className={`rounded-md px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                  activeTab === 'products'
                    ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950'
                    : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white'
                }`}
              >
                Products ({products.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('orders')}
                className={`rounded-md px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                  activeTab === 'orders'
                    ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950'
                    : 'text-zinc-600 hover:text-zinc-950 dark:text-zinc-400 dark:hover:text-white'
                }`}
              >
                Customer Orders
              </button>
            </div>

            {activeTab === 'products' && (
              <button
                type="button"
                onClick={openCreateModal}
                className="inline-flex min-h-10 items-center gap-1.5 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700"
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
                <span>Add Product</span>
              </button>
            )}
          </div>
        </div>

        {feedback && (
          <div
            role={feedback.type === 'error' ? 'alert' : 'status'}
            className={`mt-6 flex items-center gap-2.5 rounded-xl border p-4 text-sm font-medium ${
              feedback.type === 'success'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-200'
                : 'border-red-200 bg-red-50 text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle className="h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
            )}
            <span>{feedback.text}</span>
          </div>
        )}

        {/* Products Management Table */}
        {activeTab === 'products' && (
          <div className="mt-6 overflow-x-auto rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/70">
            <table className="w-full min-w-[680px] text-left text-sm">
              <thead className="border-b border-stone-200 bg-stone-50 text-xs font-semibold text-zinc-600 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-400">
                <tr>
                  <th className="px-5 py-3.5">Product</th>
                  <th className="px-5 py-3.5">Category</th>
                  <th className="px-5 py-3.5 text-right">Price</th>
                  <th className="px-5 py-3.5 text-right">Stock</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200 dark:divide-zinc-800">
                {products.map((product) => (
                  <tr key={product.id} className="hover:bg-stone-50/70 dark:hover:bg-zinc-900">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-14 shrink-0 overflow-hidden rounded-lg border border-stone-200 bg-stone-100 dark:border-zinc-800 dark:bg-zinc-900">
                          <MediaFrame
                            src={product.imageUrl}
                            alt={product.name}
                            fallbackTitle={product.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-950 dark:text-zinc-50">
                            {product.name}
                          </p>
                          <p className="text-xs text-zinc-500 dark:text-zinc-400">
                            {product.featured ? 'Featured on Home' : 'Standard Catalog'}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4 text-zinc-700 dark:text-zinc-300">
                      {product.category}
                    </td>
                    <td className="px-5 py-4 text-right font-mono font-medium tabular-nums">
                      {formatPrice(product.price)}
                    </td>
                    <td className="px-5 py-4 text-right font-mono tabular-nums">
                      <span
                        className={
                          product.stock === 0
                            ? 'font-semibold text-red-600 dark:text-red-400'
                            : product.stock <= 5
                              ? 'font-semibold text-amber-600 dark:text-amber-400'
                              : 'text-zinc-800 dark:text-zinc-200'
                        }
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditModal(product)}
                          aria-label={`Edit ${product.name}`}
                          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-zinc-600 hover:bg-stone-100 hover:text-blue-600 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-blue-400"
                        >
                          <Edit3 className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeletingProduct(product)}
                          aria-label={`Delete ${product.name}`}
                          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-zinc-600 hover:bg-red-50 hover:text-red-600 dark:text-zinc-400 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Customer Orders Management Table */}
        {activeTab === 'orders' && (
          <div className="mt-6 overflow-x-auto rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/70">
            {ordersLoading ? (
              <div className="p-10 text-center text-sm text-zinc-500">
                Loading customer orders...
              </div>
            ) : orders.length === 0 ? (
              <div className="p-10 text-center text-sm text-zinc-500">
                No customer orders have been placed yet.
              </div>
            ) : (
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="border-b border-stone-200 bg-stone-50 text-xs font-semibold text-zinc-600 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-400">
                  <tr>
                    <th className="px-5 py-3.5">Order ID</th>
                    <th className="px-5 py-3.5">Customer</th>
                    <th className="px-5 py-3.5">Items</th>
                    <th className="px-5 py-3.5 text-right">Total</th>
                    <th className="px-5 py-3.5 text-right">Order Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 dark:divide-zinc-800">
                  {orders.map((order) => (
                    <tr key={order.id} className="hover:bg-stone-50/70 dark:hover:bg-zinc-900">
                      <td className="px-5 py-4 font-mono text-xs font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
                        {order.orderNumber}
                      </td>
                      <td className="px-5 py-4">
                        <p className="font-medium text-zinc-950 dark:text-zinc-100">
                          {order.customerName}
                        </p>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">
                          {order.customerEmail}
                        </p>
                      </td>
                      <td className="px-5 py-4 text-xs text-zinc-600 dark:text-zinc-300">
                        {order.items.map((i) => `${i.name} (×${i.quantity})`).join(', ')}
                      </td>
                      <td className="px-5 py-4 text-right font-mono font-semibold tabular-nums">
                        {formatPrice(order.totalAmount)}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <select
                          aria-label={`Order status for ${order.orderNumber}`}
                          value={order.status}
                          onChange={(e) =>
                            void handleOrderStatusChange(order.id, e.target.value as OrderStatus)
                          }
                          className="rounded-lg border border-stone-300 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-900 focus:border-blue-600 focus:outline-none dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100"
                        >
                          {ORDER_STATUSES.map((status) => (
                            <option key={status} value={status}>
                              {status}
                            </option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="admin-product-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/65 p-4 backdrop-blur-sm"
          onClick={() => !savingProduct && setModalOpen(false)}
        >
          <div
            className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-stone-200 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-950"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-200 pb-4 dark:border-zinc-800">
              <h2
                id="admin-product-modal-title"
                className="text-lg font-semibold text-zinc-950 dark:text-zinc-50"
              >
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button
                type="button"
                disabled={savingProduct}
                onClick={() => setModalOpen(false)}
                aria-label="Close modal"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-stone-100 dark:hover:bg-zinc-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="mt-5 space-y-4">
              <div>
                <label className="block text-sm font-medium">Product Name</label>
                <input
                  type="text"
                  required
                  value={formState.name}
                  onChange={(e) => setFormState((p) => ({...p, name: e.target.value}))}
                  className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium">Category</label>
                  <select
                    value={formState.category}
                    onChange={(e) =>
                      setFormState((p) => ({...p, category: e.target.value as ProductCategory}))
                    }
                    className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                  >
                    <option value="Keyboards">Keyboards</option>
                    <option value="Audio">Audio</option>
                    <option value="Lighting">Lighting</option>
                    <option value="Accessories">Accessories</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium">Price (₹)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={formState.price}
                    onChange={(e) => setFormState((p) => ({...p, price: Number(e.target.value)}))}
                    className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3 py-2 font-mono text-sm tabular-nums dark:border-zinc-700 dark:bg-zinc-900"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium">Stock</label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={formState.stock}
                    onChange={(e) => setFormState((p) => ({...p, stock: Number(e.target.value)}))}
                    className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3 py-2 font-mono text-sm tabular-nums dark:border-zinc-700 dark:bg-zinc-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium">Studio Image Preset</label>
                <select
                  value={
                    STUDIO_IMAGE_PRESETS.some((p) => p.url === formState.imageUrl)
                      ? formState.imageUrl
                      : 'custom'
                  }
                  onChange={(e) => {
                    if (e.target.value !== 'custom') {
                      setFormState((p) => ({...p, imageUrl: e.target.value}));
                    }
                  }}
                  className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                >
                  {STUDIO_IMAGE_PRESETS.map((preset) => (
                    <option key={preset.url} value={preset.url}>
                      {preset.label}
                    </option>
                  ))}
                  <option value="custom">Custom Image URL</option>
                </select>
                <input
                  type="text"
                  required
                  value={formState.imageUrl}
                  onChange={(e) => setFormState((p) => ({...p, imageUrl: e.target.value}))}
                  placeholder="/src/assets/images/... or https://..."
                  className="mt-2 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2 text-xs dark:border-zinc-700 dark:bg-zinc-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium">Description</label>
                <textarea
                  rows={3}
                  required
                  value={formState.description}
                  onChange={(e) => setFormState((p) => ({...p, description: e.target.value}))}
                  className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium">
                  Specifications (one per line)
                </label>
                <textarea
                  rows={3}
                  value={specsText}
                  onChange={(e) => setSpecsText(e.target.value)}
                  placeholder="CNC Anodized Aluminum&#10;USB-C Connectivity"
                  className="mt-1 block w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                />
              </div>

              <label className="flex items-center gap-2 text-sm font-medium">
                <input
                  type="checkbox"
                  checked={Boolean(formState.featured)}
                  onChange={(e) => setFormState((p) => ({...p, featured: e.target.checked}))}
                />
                <span>Feature on Home Page</span>
              </label>

              <div className="flex justify-end gap-3 border-t border-stone-200 pt-4 dark:border-zinc-800">
                <button
                  type="button"
                  disabled={savingProduct}
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-stone-300 px-4 py-2 text-sm font-medium dark:border-zinc-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProduct}
                  className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
                >
                  {savingProduct ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  <span>{editingProduct ? 'Save Product' : 'Create Product'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Product Confirmation Modal */}
      {deletingProduct && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/65 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-stone-200 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <h2 className="text-lg font-semibold text-zinc-950 dark:text-zinc-50">
              Remove Product
            </h2>
            <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-300">
              Delete <strong>{deletingProduct.name}</strong> from the store catalog?
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                disabled={deletingInFlight}
                onClick={() => setDeletingProduct(null)}
                className="rounded-lg border border-stone-300 px-4 py-2 text-sm font-medium dark:border-zinc-700"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deletingInFlight}
                onClick={() => void handleConfirmDelete()}
                className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
              >
                {deletingInFlight ? 'Removing...' : 'Delete Product'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
