import {Package} from 'lucide-react';
import {useState} from 'react';

interface MediaFrameProps {
  src: string;
  alt: string;
  fallbackTitle: string;
  className?: string;
}

export function MediaFrame({src, alt, fallbackTitle, className = ''}: MediaFrameProps) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-stone-100 via-stone-200/70 to-stone-100 p-6 text-center dark:from-zinc-900 dark:via-zinc-800/80 dark:to-zinc-900 ${className}`}
      >
        <Package className="h-7 w-7 text-stone-500 dark:text-zinc-400" aria-hidden="true" />
        <p className="text-xs font-medium text-stone-600 dark:text-zinc-300">{fallbackTitle}</p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
