import {Menu, Moon, ShoppingBag, Sun, X} from 'lucide-react';
import {useState} from 'react';
import type {ThemeMode} from '../hooks/useTheme.ts';
import type {AuthUser} from '../types/store.ts';

export type AppRoute =
  | '/'
  | '/products'
  | `/products/${string}`
  | '/cart'
  | '/checkout'
  | '/login'
  | '/register'
  | '/profile'
  | '/orders'
  | '/admin';

interface NavbarProps {
  currentPath: string;
  user: AuthUser | null;
  cartCount: number;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onNavigate: (path: string) => void;
}

export function Navbar({
  currentPath,
  user,
  cartCount,
  theme,
  onToggleTheme,
  onNavigate,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: Array<{label: string; path: string}> = [
    {label: 'Home', path: '/'},
    {label: 'Shop', path: '/products'},
    ...(user ? [{label: 'Orders', path: '/orders'}] : []),
    ...(user?.role === 'admin' ? [{label: 'Admin', path: '/admin'}] : []),
    {label: user ? 'Profile' : 'Sign In', path: user ? '/profile' : '/login'},
  ];

  const handleNav = (path: string) => {
    setMobileOpen(false);
    onNavigate(path);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200 bg-stone-50/95 backdrop-blur-md transition-colors duration-200 dark:border-zinc-800 dark:bg-zinc-950/95">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-line brand wordmark */}
        <button
          type="button"
          onClick={() => handleNav('/')}
          className="shrink-0 whitespace-nowrap text-left text-lg font-bold tracking-tight text-zinc-950 transition-colors hover:text-blue-600 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 dark:text-zinc-50 dark:hover:text-blue-400"
        >
          Kanso Goods
        </button>

        {/* Zone 2: 4–5 single-line navigation links */}
        <nav aria-label="Store navigation" className="hidden items-center gap-6 md:flex">
          {navItems.map((item) => {
            const isActive =
              item.path === '/'
                ? currentPath === '/'
                : currentPath === item.path || currentPath.startsWith(`${item.path}/`);
            return (
              <button
                key={item.path}
                type="button"
                onClick={() => handleNav(item.path)}
                className={`shrink-0 whitespace-nowrap text-sm font-medium underline-offset-4 transition-colors duration-150 hover:text-zinc-950 hover:underline dark:hover:text-white ${
                  isActive
                    ? 'text-zinc-950 underline dark:text-white'
                    : 'text-zinc-600 dark:text-zinc-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Bag CTA + Mobile menu trigger */}
        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={() => handleNav('/cart')}
            className="inline-flex min-h-10 shrink-0 items-center gap-2 whitespace-nowrap rounded-lg bg-zinc-900 px-4 py-2 text-xs font-semibold tabular-nums text-white transition-colors duration-150 hover:bg-blue-600 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-blue-500 dark:hover:text-white"
          >
            <ShoppingBag className="h-4 w-4" aria-hidden="true" />
            <span>Bag ({cartCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-stone-200 text-zinc-700 hover:bg-stone-100 md:hidden dark:border-zinc-800 dark:text-zinc-200 dark:hover:bg-zinc-900"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Responsive Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="border-t border-stone-200 bg-white px-4 py-4 md:hidden dark:border-zinc-800 dark:bg-zinc-950">
          <nav aria-label="Mobile store navigation" className="flex flex-col gap-1">
            {navItems.map((item) => (
              <button
                key={item.path}
                type="button"
                onClick={() => handleNav(item.path)}
                className="flex min-h-11 items-center rounded-lg px-3 text-left text-base font-medium text-zinc-800 hover:bg-stone-100 dark:text-zinc-200 dark:hover:bg-zinc-900"
              >
                {item.label}
              </button>
            ))}
            {!user && (
              <button
                type="button"
                onClick={() => handleNav('/register')}
                className="flex min-h-11 items-center rounded-lg px-3 text-left text-base font-medium text-zinc-800 hover:bg-stone-100 dark:text-zinc-200 dark:hover:bg-zinc-900"
              >
                Create Account
              </button>
            )}
          </nav>

          <div className="mt-4 flex items-center justify-between border-t border-stone-200 pt-4 dark:border-zinc-800">
            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-stone-200 px-3 py-2 text-xs font-medium text-zinc-700 dark:border-zinc-800 dark:text-zinc-200"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="h-4 w-4" />
                  <span>Light Mode</span>
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4" />
                  <span>Dark Mode</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => handleNav('/cart')}
              className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-zinc-900 px-4 py-2 text-xs font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
            >
              <ShoppingBag className="h-4 w-4" />
              <span>View Bag ({cartCount})</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
