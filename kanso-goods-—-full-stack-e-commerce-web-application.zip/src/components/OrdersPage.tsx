import {AlertCircle, CheckCircle2, Package, RefreshCw, Truck} from 'lucide-react';
import {useCallback, useEffect, useState} from 'react';
import {fetchMyOrders} from '../services/api.ts';
import type {OrderRecord, OrderStatus} from '../types/store.ts';
import {formatPrice} from '../utils/currency.ts';
import {MediaFrame} from './MediaFrame.tsx';

interface OrdersPageProps {
  token: string;
  highlightedOrderNumber?: string | null;
  onShopNow: () => void;
}

const ORDER_STEPS: OrderStatus[] = ['Pending', 'Processing', 'Shipped', 'Delivered'];

export function OrdersPage({
  token,
  highlightedOrderNumber,
  onShopNow,
}: OrdersPageProps) {
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchMyOrders(token);
      setOrders(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load order history.');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    void loadOrders();
  }, [loadOrders]);

  return (
    <section className="py-10 sm:py-14">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-6 dark:border-zinc-800">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-zinc-50 sm:text-3xl">
              My Orders
            </h1>
            <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-400">
              Track order progress from confirmation through delivery.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void loadOrders()}
            className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3.5 py-2 text-xs font-semibold text-zinc-800 hover:bg-stone-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Refresh</span>
          </button>
        </div>

        {highlightedOrderNumber && (
          <div
            role="status"
            className="mt-6 flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-200"
          >
            <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <div>
              <p className="font-semibold">
                Order {highlightedOrderNumber} Confirmed — Status: Pending
              </p>
              <p className="mt-0.5 text-xs">
                Your demo order has been recorded and inventory has been updated.
              </p>
            </div>
          </div>
        )}

        {loading && (
          <div className="mt-8 space-y-4">
            {[0, 1].map((idx) => (
              <div
                key={idx}
                className="h-44 animate-pulse rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900"
              />
            ))}
          </div>
        )}

        {!loading && error && (
          <div
            role="alert"
            className="mt-8 flex items-center justify-between gap-4 rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200"
          >
            <div className="flex items-center gap-2.5">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              type="button"
              onClick={() => void loadOrders()}
              className="rounded-lg bg-red-700 px-4 py-2 text-xs font-semibold text-white"
            >
              Retry
            </button>
          </div>
        )}

        {!loading && !error && orders.length === 0 && (
          <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-12 text-center dark:border-zinc-800 dark:bg-zinc-900">
            <Package className="mx-auto h-9 w-9 text-zinc-400 dark:text-zinc-600" />
            <h2 className="mt-3 text-base font-semibold text-zinc-950 dark:text-zinc-50">
              No orders placed yet
            </h2>
            <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-400">
              Once you place an order through checkout, you can track its status here.
            </p>
            <button
              type="button"
              onClick={onShopNow}
              className="mt-5 inline-flex min-h-10 items-center rounded-lg bg-zinc-900 px-5 py-2 text-sm font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
            >
              Browse Catalog
            </button>
          </div>
        )}

        {!loading && !error && orders.length > 0 && (
          <div className="mt-8 space-y-6">
            {orders.map((order) => {
              const currentStepIdx = ORDER_STEPS.indexOf(order.status);
              return (
                <article
                  key={order.id}
                  className="overflow-hidden rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/70"
                >
                  <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 bg-stone-50/80 px-6 py-4 dark:border-zinc-800 dark:bg-zinc-950/60">
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-xs">
                      <div>
                        <span className="text-zinc-500 dark:text-zinc-400">Order ID: </span>
                        <span className="font-mono font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
                          {order.orderNumber}
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-500 dark:text-zinc-400">Placed: </span>
                        <span className="font-mono tabular-nums text-zinc-800 dark:text-zinc-200">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-500 dark:text-zinc-400">Total: </span>
                        <span className="font-mono font-semibold tabular-nums text-zinc-950 dark:text-zinc-50">
                          {formatPrice(order.totalAmount)}
                        </span>
                      </div>
                    </div>

                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400">
                      <Truck className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Status: {order.status}</span>
                    </span>
                  </div>

                  {/* 4-Step Order Progress Bar */}
                  <div className="border-b border-stone-200 px-6 py-4 dark:border-zinc-800">
                    <div className="grid grid-cols-4 gap-2">
                      {ORDER_STEPS.map((step, idx) => {
                        const completed = idx <= currentStepIdx;
                        return (
                          <div key={step}>
                            <div
                              className={`h-1.5 rounded-full ${
                                completed
                                  ? 'bg-blue-600 dark:bg-blue-500'
                                  : 'bg-stone-200 dark:bg-zinc-800'
                              }`}
                            />
                            <p
                              className={`mt-1.5 text-xs font-medium ${
                                completed
                                  ? 'text-zinc-950 dark:text-zinc-100'
                                  : 'text-zinc-400 dark:text-zinc-500'
                              }`}
                            >
                              {step}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Order Items & Shipping */}
                  <div className="grid gap-6 p-6 md:grid-cols-12">
                    <ul className="space-y-3 md:col-span-8">
                      {order.items.map((item) => (
                        <li
                          key={`${order.id}-${item.productId}`}
                          className="flex items-center justify-between gap-4 text-sm"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-14 shrink-0 overflow-hidden rounded-lg border border-stone-200 bg-stone-100 dark:border-zinc-800 dark:bg-zinc-900">
                              <MediaFrame
                                src={item.imageUrl}
                                alt={item.name}
                                fallbackTitle={item.name}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <div>
                              <p className="font-medium text-zinc-950 dark:text-zinc-100">
                                {item.name}
                              </p>
                              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                                Qty {item.quantity} × {formatPrice(item.price)}
                              </p>
                            </div>
                          </div>
                          <span className="font-mono font-medium tabular-nums text-zinc-900 dark:text-zinc-100">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <div className="border-t border-stone-200 pt-4 text-xs text-zinc-600 md:col-span-4 md:border-l md:border-t-0 md:pl-6 md:pt-0 dark:border-zinc-800 dark:text-zinc-400">
                      <p className="font-semibold text-zinc-900 dark:text-zinc-100">
                        Shipping Destination
                      </p>
                      <p className="mt-1.5 font-medium text-zinc-800 dark:text-zinc-200">
                        {order.shippingAddress.fullName}
                      </p>
                      <p>{order.shippingAddress.street}</p>
                      <p>
                        {order.shippingAddress.city}, {order.shippingAddress.state}{' '}
                        {order.shippingAddress.postalCode}
                      </p>
                      <p className="mt-1 font-mono tabular-nums">{order.shippingAddress.phone}</p>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
