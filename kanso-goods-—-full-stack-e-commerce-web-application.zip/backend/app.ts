import cors from 'cors';
import express from 'express';
import {isMongoConnected} from './config/db.ts';
import {apiNotFoundHandler, globalErrorHandler} from './middleware/errorHandler.ts';
import authRoutes from './routes/authRoutes.ts';
import cartRoutes from './routes/cartRoutes.ts';
import orderRoutes from './routes/orderRoutes.ts';
import productRoutes from './routes/productRoutes.ts';

export function createApiApp() {
  const app = express();

  app.set('trust proxy', 1);

  const allowedOrigins = (process.env.FRONTEND_URL || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  app.use(
    cors({
      origin(origin, callback) {
        if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
          callback(null, true);
          return;
        }
        callback(new Error('Origin not permitted by CORS policy'));
      },
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization'],
    }),
  );

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({limit: '32kb'}));

  app.get('/api/health', (_req, res) => {
    res.json({
      success: true,
      status: 'ok',
      database: isMongoConnected() ? 'mongodb' : 'preview-store',
    });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/cart', cartRoutes);
  app.use('/api/orders', orderRoutes);

  app.use('/api', apiNotFoundHandler);
  app.use(globalErrorHandler);

  return app;
}
