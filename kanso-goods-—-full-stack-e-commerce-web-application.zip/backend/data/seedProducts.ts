import type {ProductFormPayload} from '../../src/types/store.ts';

export const HERO_BANNER_IMAGE = '/src/assets/images/hero_studio_gear_1795477484726.jpg';

export const SEED_PRODUCTS: Array<ProductFormPayload & {slug: string}> = [
  {
    slug: 'kanso-65-aluminum-mechanical-keyboard',
    name: 'Kanso 65 Aluminum Keyboard',
    category: 'Keyboards',
    price: 8490,
    stock: 14,
    description:
      'CNC-machined 6063 anodized aluminum 65% mechanical keyboard engineered with gasket-mounted typing acoustics, hot-swappable PCB sockets, and double-shot PBT keycaps.',
    specs: [
      '65% Compact Layout (67 Keys)',
      'CNC Anodized Charcoal Aluminum Chassis',
      'Hot-Swappable 5-Pin PCB · USB-C',
      'Double-Shot Matte PBT Keycaps',
    ],
    imageUrl: '/src/assets/images/product_mech_keyboard_1795477485526.jpg',
    featured: true,
  },
  {
    slug: 'aether-studio-wireless-headphones',
    name: 'Aether Studio Monitor Headphones',
    category: 'Audio',
    price: 11990,
    stock: 9,
    description:
      'Closed-back wireless reference headphones featuring brushed aluminum earcups, 40mm beryllium-coated drivers, and memory-foam lambskin cushions for long engineering sessions.',
    specs: [
      '40mm Dynamic Studio Drivers',
      '45-Hour Battery Life · USB-C Fast Charge',
      'Brushed Aluminum Yoke & Headband',
      'Dual-Mode Bluetooth 5.3 & Wired Lossless',
    ],
    imageUrl: '/src/assets/images/product_studio_headphones_1795477484901.jpg',
    featured: true,
  },
  {
    slug: 'linea-architectural-task-lamp',
    name: 'Linea Architectural Task Lamp',
    category: 'Lighting',
    price: 5290,
    stock: 18,
    description:
      'Precision-balanced articulated desk lamp with stepless rotary dimming, high-CRI 97+ glare-free illumination, and a knurled stainless steel dimmer dial.',
    specs: [
      'CRI 97+ Flicker-Free LED Array',
      '2700K–5000K Tunable Color Temperature',
      'Machined Steel Rotary Dimmer Control',
      'Dual-Axis Articulated Aluminum Arm',
    ],
    imageUrl: '/src/assets/images/product_desk_lamp_1795477484828.jpg',
    featured: true,
  },
  {
    slug: 'nexus-10gbps-usbc-workstation-dock',
    name: 'Precision USB-C 7-in-1 Dock',
    category: 'Accessories',
    price: 3890,
    stock: 22,
    description:
      'Milled silver aluminum desktop hub expanding a single USB-C port into 10Gbps data ports, 100W Power Delivery pass-through, and high-speed SD/microSD readers.',
    specs: [
      '100W USB-C Power Delivery Pass-Through',
      '2× USB-A 3.2 (10Gbps) + USB-C Data',
      'UHS-II SD & microSD Card Slots',
      'Braided Shielded Host Cable',
    ],
    imageUrl: '/src/assets/images/product_usbc_dock_1795477485806.jpg',
    featured: false,
  },
  {
    slug: 'monolith-leather-laptop-sleeve',
    name: 'Monolith Full-Grain Sleeve & Stylus',
    category: 'Accessories',
    price: 3490,
    stock: 12,
    description:
      'Structured 14-inch laptop folio crafted from vegetable-tanned full-grain leather with microfiber interior lining and an integrated anodized aluminum pen loop.',
    specs: [
      'Fits 13" to 14" Laptops & Tablets',
      'Full-Grain Vegetable-Tanned Leather',
      'Includes Machined Aluminum Ballpoint Pen',
      'Concealed Magnetic Closure',
    ],
    imageUrl: '/src/assets/images/product_leather_sleeve_1795477486275.jpg',
    featured: false,
  },
  {
    slug: 'kuro-stoneware-desk-tumbler',
    name: 'Kuro Stoneware Desk Tumbler',
    category: 'Accessories',
    price: 1690,
    stock: 30,
    description:
      'Double-wall ceramic-lined matte stoneware desk mug finished with a turned walnut coaster lid to keep coffee or tea warm during focused coding blocks.',
    specs: [
      '350ml Capacity · Matte Charcoal Glaze',
      'Solid Turned Walnut Lid & Coaster',
      'Ceramic-Coated Heat Retention Core',
      'Ergonomic Weighted Base',
    ],
    imageUrl: '/src/assets/images/product_ceramic_mug_1795477486450.jpg',
    featured: false,
  },
];
