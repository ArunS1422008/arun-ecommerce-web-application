import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import {isMongoConnected} from '../config/db.ts';
import {SEED_PRODUCTS} from '../data/seedProducts.ts';
import {CartModel} from '../models/Cart.ts';
import {OrderModel} from '../models/Order.ts';
import {ProductModel} from '../models/Product.ts';
import {UserModel} from '../models/User.ts';
import type {
  AuthUser,
  CartLineItem,
  OrderLineItem,
  OrderRecord,
  OrderStatus,
  ProductCategory,
  ProductFormPayload,
  ProductItem,
  ProductSortOption,
  ShippingAddress,
  UserRole,
} from '../../src/types/store.ts';

interface StoredUser {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  createdAt: string;
}

interface StoredCart {
  userId: string;
  items: Array<{productId: string; quantity: number}>;
}

interface FallbackEcommerceDb {
  users: StoredUser[];
  products: ProductItem[];
  carts: StoredCart[];
  orders: OrderRecord[];
}

const FALLBACK_FILE = path.resolve('/tmp', 'arun-ecommerce-preview-db.json');

export const FREE_SHIPPING_THRESHOLD = 2999;
export const STANDARD_SHIPPING_FEE = 149;

let memoryDb: FallbackEcommerceDb = {
  users: [],
  products: [],
  carts: [],
  orders: [],
};

function makeSlug(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  const suffix = crypto.randomBytes(3).toString('hex');
  return `${base || 'product'}-${suffix}`;
}

async function persistFallback(): Promise<void> {
  try {
    await fs.writeFile(FALLBACK_FILE, JSON.stringify(memoryDb, null, 2), 'utf8');
  } catch (err) {
    console.warn('[Store] Failed writing preview store:', err instanceof Error ? err.message : err);
  }
}

export async function initializeStoreDatabase(): Promise<void> {
  if (isMongoConnected()) {
    const productCount = await ProductModel.countDocuments();
    if (productCount === 0) {
      await ProductModel.insertMany(SEED_PRODUCTS);
      console.info('[DB] Seeded initial e-commerce products in MongoDB.');
    }
    return;
  }

  try {
    const raw = await fs.readFile(FALLBACK_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<FallbackEcommerceDb>;
    if (Array.isArray(parsed.products) && parsed.products.length > 0) {
      memoryDb = {
        users: Array.isArray(parsed.users) ? parsed.users : [],
        products: parsed.products,
        carts: Array.isArray(parsed.carts) ? parsed.carts : [],
        orders: Array.isArray(parsed.orders) ? parsed.orders : [],
      };
      return;
    }
  } catch {
    // Initialize fresh seed
  }

  const now = new Date().toISOString();
  memoryDb = {
    users: [],
    products: SEED_PRODUCTS.map((item) => ({
      id: crypto.randomUUID(),
      slug: item.slug,
      name: item.name,
      category: item.category,
      price: item.price,
      stock: item.stock,
      description: item.description,
      specs: item.specs,
      imageUrl: item.imageUrl,
      featured: Boolean(item.featured),
      createdAt: now,
      updatedAt: now,
    })),
    carts: [],
    orders: [],
  };
  await persistFallback();
}

function toAuthUser(u: {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt?: Date | string;
}): AuthUser {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    createdAt:
      u.createdAt instanceof Date
        ? u.createdAt.toISOString()
        : u.createdAt || new Date().toISOString(),
  };
}

function mapMongoProduct(doc: {
  _id: unknown;
  slug: string;
  name: string;
  category: ProductCategory;
  price: number;
  stock: number;
  description: string;
  specs: string[];
  imageUrl: string;
  featured: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}): ProductItem {
  return {
    id: String(doc._id),
    slug: doc.slug,
    name: doc.name,
    category: doc.category,
    price: doc.price,
    stock: doc.stock,
    description: doc.description,
    specs: Array.isArray(doc.specs) ? doc.specs : [],
    imageUrl: doc.imageUrl,
    featured: Boolean(doc.featured),
    createdAt: doc.createdAt?.toISOString(),
    updatedAt: doc.updatedAt?.toISOString(),
  };
}

function mapMongoOrder(doc: {
  _id: unknown;
  orderNumber: string;
  userId: unknown;
  customerName: string;
  customerEmail: string;
  items: OrderLineItem[];
  shippingAddress: ShippingAddress;
  paymentMethod: 'cod' | 'demo-invoice';
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  status: OrderStatus;
  createdAt: Date;
  updatedAt: Date;
}): OrderRecord {
  return {
    id: String(doc._id),
    orderNumber: doc.orderNumber,
    userId: String(doc.userId),
    customerName: doc.customerName,
    customerEmail: doc.customerEmail,
    items: doc.items,
    shippingAddress: doc.shippingAddress,
    paymentMethod: doc.paymentMethod,
    subtotal: doc.subtotal,
    shippingFee: doc.shippingFee,
    totalAmount: doc.totalAmount,
    status: doc.status,
    createdAt: doc.createdAt.toISOString(),
    updatedAt: doc.updatedAt.toISOString(),
  };
}

// ---------- Auth & Users ----------

export async function hasAdminAccount(): Promise<boolean> {
  if (isMongoConnected()) {
    const count = await UserModel.countDocuments({role: 'admin'});
    return count > 0;
  }
  return memoryDb.users.some((u) => u.role === 'admin');
}

export async function createAccount(input: {
  name: string;
  email: string;
  password: string;
  role: UserRole;
}): Promise<{user?: AuthUser; conflict?: boolean}> {
  const normalizedEmail = input.email.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(input.password, 12);

  if (isMongoConnected()) {
    const existing = await UserModel.findOne({email: normalizedEmail}).lean();
    if (existing) {
      return {conflict: true};
    }
    const created = await UserModel.create({
      name: input.name.trim(),
      email: normalizedEmail,
      passwordHash,
      role: input.role,
    });
    return {
      user: toAuthUser({
        id: String(created._id),
        name: created.name,
        email: created.email,
        role: created.role,
        createdAt: created.createdAt,
      }),
    };
  }

  if (memoryDb.users.some((u) => u.email === normalizedEmail)) {
    return {conflict: true};
  }

  const created: StoredUser = {
    id: crypto.randomUUID(),
    name: input.name.trim(),
    email: normalizedEmail,
    passwordHash,
    role: input.role,
    createdAt: new Date().toISOString(),
  };
  memoryDb.users.push(created);
  await persistFallback();
  return {user: toAuthUser(created)};
}

export async function authenticateAccount(
  email: string,
  password: string,
): Promise<AuthUser | null> {
  const normalizedEmail = email.trim().toLowerCase();

  if (isMongoConnected()) {
    const doc = await UserModel.findOne({email: normalizedEmail});
    if (!doc) {
      return null;
    }
    const matches = await bcrypt.compare(password, doc.passwordHash);
    if (!matches) {
      return null;
    }
    return toAuthUser({
      id: String(doc._id),
      name: doc.name,
      email: doc.email,
      role: doc.role,
      createdAt: doc.createdAt,
    });
  }

  const user = memoryDb.users.find((u) => u.email === normalizedEmail);
  if (!user) {
    return null;
  }
  const matches = await bcrypt.compare(password, user.passwordHash);
  if (!matches) {
    return null;
  }
  return toAuthUser(user);
}

export async function findUserById(userId: string): Promise<AuthUser | null> {
  if (isMongoConnected()) {
    const doc = await UserModel.findById(userId).select('-passwordHash').lean();
    if (!doc) {
      return null;
    }
    return toAuthUser({
      id: String(doc._id),
      name: doc.name,
      email: doc.email,
      role: doc.role,
      createdAt: doc.createdAt,
    });
  }

  const user = memoryDb.users.find((u) => u.id === userId);
  return user ? toAuthUser(user) : null;
}

export async function updateUserDisplayName(
  userId: string,
  name: string,
): Promise<AuthUser | null> {
  const cleaned = name.trim();
  if (isMongoConnected()) {
    const doc = await UserModel.findByIdAndUpdate(
      userId,
      {name: cleaned},
      {new: true},
    ).select('-passwordHash');
    if (!doc) {
      return null;
    }
    return toAuthUser({
      id: String(doc._id),
      name: doc.name,
      email: doc.email,
      role: doc.role,
      createdAt: doc.createdAt,
    });
  }

  const idx = memoryDb.users.findIndex((u) => u.id === userId);
  if (idx === -1) {
    return null;
  }
  memoryDb.users[idx] = {...memoryDb.users[idx], name: cleaned};
  await persistFallback();
  return toAuthUser(memoryDb.users[idx]);
}

// ---------- Products ----------

export async function listProducts(options: {
  category?: ProductCategory;
  search?: string;
  sort?: ProductSortOption;
} = {}): Promise<ProductItem[]> {
  if (isMongoConnected()) {
    const filter: Record<string, unknown> = {};
    if (options.category) {
      filter.category = options.category;
    }
    if (options.search) {
      const escaped = options.search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filter.$or = [
        {name: {$regex: escaped, $options: 'i'}},
        {description: {$regex: escaped, $options: 'i'}},
        {category: {$regex: escaped, $options: 'i'}},
      ];
    }

    const sortSpec: Record<string, 1 | -1> =
      options.sort === 'price-asc'
        ? {price: 1}
        : options.sort === 'price-desc'
          ? {price: -1}
          : {featured: -1, createdAt: 1};

    const docs = await ProductModel.find(filter).sort(sortSpec).lean();
    return docs.map((d) => mapMongoProduct(d));
  }

  let list = [...memoryDb.products];
  if (options.category) {
    list = list.filter((p) => p.category === options.category);
  }
  if (options.search) {
    const q = options.search.toLowerCase();
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q),
    );
  }

  if (options.sort === 'price-asc') {
    list.sort((a, b) => a.price - b.price);
  } else if (options.sort === 'price-desc') {
    list.sort((a, b) => b.price - a.price);
  } else {
    list.sort((a, b) => Number(b.featured) - Number(a.featured));
  }
  return list;
}

export async function getProductByIdOrSlug(idOrSlug: string): Promise<ProductItem | null> {
  if (isMongoConnected()) {
    const isObjectId = /^[a-f0-9]{24}$/i.test(idOrSlug);
    const doc = isObjectId
      ? await ProductModel.findById(idOrSlug).lean()
      : await ProductModel.findOne({slug: idOrSlug}).lean();
    return doc ? mapMongoProduct(doc) : null;
  }

  return (
    memoryDb.products.find((p) => p.id === idOrSlug || p.slug === idOrSlug) || null
  );
}

export async function createProduct(payload: ProductFormPayload): Promise<ProductItem> {
  const slug = makeSlug(payload.name);
  if (isMongoConnected()) {
    const created = await ProductModel.create({
      slug,
      name: payload.name.trim(),
      category: payload.category,
      price: payload.price,
      stock: payload.stock,
      description: payload.description.trim(),
      specs: payload.specs,
      imageUrl: payload.imageUrl.trim(),
      featured: Boolean(payload.featured),
    });
    return mapMongoProduct(created);
  }

  const now = new Date().toISOString();
  const product: ProductItem = {
    id: crypto.randomUUID(),
    slug,
    name: payload.name.trim(),
    category: payload.category,
    price: payload.price,
    stock: payload.stock,
    description: payload.description.trim(),
    specs: payload.specs,
    imageUrl: payload.imageUrl.trim(),
    featured: Boolean(payload.featured),
    createdAt: now,
    updatedAt: now,
  };
  memoryDb.products.unshift(product);
  await persistFallback();
  return product;
}

export async function updateProduct(
  productId: string,
  payload: Partial<ProductFormPayload>,
): Promise<ProductItem | null> {
  if (isMongoConnected()) {
    const doc = await ProductModel.findById(productId);
    if (!doc) {
      return null;
    }
    if (payload.name !== undefined) doc.name = payload.name.trim();
    if (payload.category !== undefined) doc.category = payload.category;
    if (payload.price !== undefined) doc.price = payload.price;
    if (payload.stock !== undefined) doc.stock = payload.stock;
    if (payload.description !== undefined) doc.description = payload.description.trim();
    if (payload.specs !== undefined) doc.specs = payload.specs;
    if (payload.imageUrl !== undefined) doc.imageUrl = payload.imageUrl.trim();
    if (payload.featured !== undefined) doc.featured = Boolean(payload.featured);
    await doc.save();
    return mapMongoProduct(doc);
  }

  const idx = memoryDb.products.findIndex((p) => p.id === productId);
  if (idx === -1) {
    return null;
  }
  const existing = memoryDb.products[idx];
  const updated: ProductItem = {
    ...existing,
    name: payload.name !== undefined ? payload.name.trim() : existing.name,
    category: payload.category !== undefined ? payload.category : existing.category,
    price: payload.price !== undefined ? payload.price : existing.price,
    stock: payload.stock !== undefined ? payload.stock : existing.stock,
    description:
      payload.description !== undefined ? payload.description.trim() : existing.description,
    specs: payload.specs !== undefined ? payload.specs : existing.specs,
    imageUrl: payload.imageUrl !== undefined ? payload.imageUrl.trim() : existing.imageUrl,
    featured: payload.featured !== undefined ? Boolean(payload.featured) : existing.featured,
    updatedAt: new Date().toISOString(),
  };
  memoryDb.products[idx] = updated;
  await persistFallback();
  return updated;
}

export async function deleteProduct(productId: string): Promise<boolean> {
  if (isMongoConnected()) {
    const deleted = await ProductModel.findByIdAndDelete(productId);
    return Boolean(deleted);
  }
  const idx = memoryDb.products.findIndex((p) => p.id === productId);
  if (idx === -1) {
    return false;
  }
  memoryDb.products.splice(idx, 1);
  await persistFallback();
  return true;
}

// ---------- Cart ----------

async function hydrateCart(
  rawItems: Array<{productId: string; quantity: number}>,
): Promise<CartLineItem[]> {
  const allProducts = await listProducts();
  const byId = new Map(allProducts.map((p) => [p.id, p]));
  const result: CartLineItem[] = [];

  for (const item of rawItems) {
    const product = byId.get(item.productId);
    if (product && product.stock > 0) {
      result.push({
        productId: product.id,
        quantity: Math.min(item.quantity, product.stock),
        product,
      });
    }
  }
  return result;
}

async function getRawCartItems(
  userId: string,
): Promise<Array<{productId: string; quantity: number}>> {
  if (isMongoConnected()) {
    const doc = await CartModel.findOne({userId}).lean();
    return doc ? doc.items.map((i) => ({productId: i.productId, quantity: i.quantity})) : [];
  }
  const cart = memoryDb.carts.find((c) => c.userId === userId);
  return cart ? [...cart.items] : [];
}

async function saveRawCartItems(
  userId: string,
  items: Array<{productId: string; quantity: number}>,
): Promise<void> {
  if (isMongoConnected()) {
    await CartModel.findOneAndUpdate(
      {userId},
      {userId, items},
      {upsert: true, new: true},
    );
    return;
  }

  const idx = memoryDb.carts.findIndex((c) => c.userId === userId);
  if (idx === -1) {
    memoryDb.carts.push({userId, items});
  } else {
    memoryDb.carts[idx] = {userId, items};
  }
  await persistFallback();
}

export async function getUserCart(userId: string): Promise<CartLineItem[]> {
  const raw = await getRawCartItems(userId);
  return hydrateCart(raw);
}

export async function addToUserCart(
  userId: string,
  productId: string,
  quantity: number,
): Promise<{cart?: CartLineItem[]; error?: string; status?: number}> {
  const product = await getProductByIdOrSlug(productId);
  if (!product) {
    return {error: 'Product not found.', status: 404};
  }
  if (product.stock < 1) {
    return {error: 'This product is currently out of stock.', status: 400};
  }

  const items = await getRawCartItems(userId);
  const existingIdx = items.findIndex((i) => i.productId === product.id);
  const nextQty =
    existingIdx === -1 ? quantity : items[existingIdx].quantity + quantity;
  const clampedQty = Math.min(nextQty, product.stock);

  if (existingIdx === -1) {
    items.push({productId: product.id, quantity: clampedQty});
  } else {
    items[existingIdx] = {productId: product.id, quantity: clampedQty};
  }

  await saveRawCartItems(userId, items);
  return {cart: await hydrateCart(items)};
}

export async function updateUserCartItem(
  userId: string,
  productId: string,
  quantity: number,
): Promise<{cart?: CartLineItem[]; error?: string; status?: number}> {
  const product = await getProductByIdOrSlug(productId);
  if (!product) {
    return {error: 'Product not found.', status: 404};
  }

  const items = await getRawCartItems(userId);
  if (quantity <= 0) {
    const filtered = items.filter((i) => i.productId !== product.id);
    await saveRawCartItems(userId, filtered);
    return {cart: await hydrateCart(filtered)};
  }

  if (product.stock < 1) {
    return {error: 'Product is out of stock.', status: 400};
  }

  const clamped = Math.min(quantity, product.stock);
  const idx = items.findIndex((i) => i.productId === product.id);
  if (idx === -1) {
    items.push({productId: product.id, quantity: clamped});
  } else {
    items[idx] = {productId: product.id, quantity: clamped};
  }

  await saveRawCartItems(userId, items);
  return {cart: await hydrateCart(items)};
}

export async function removeUserCartItem(
  userId: string,
  productId: string,
): Promise<CartLineItem[]> {
  const items = await getRawCartItems(userId);
  const filtered = items.filter((i) => i.productId !== productId);
  await saveRawCartItems(userId, filtered);
  return hydrateCart(filtered);
}

export async function clearUserCart(userId: string): Promise<void> {
  await saveRawCartItems(userId, []);
}

export async function mergeGuestCart(
  userId: string,
  guestItems: Array<{productId: string; quantity: number}>,
): Promise<CartLineItem[]> {
  for (const item of guestItems) {
    await addToUserCart(userId, item.productId, item.quantity);
  }
  return getUserCart(userId);
}

// ---------- Orders ----------

function generateOrderNumber(): string {
  const year = new Date().getFullYear();
  const code = crypto.randomInt(100000, 999999);
  return `ORD-${year}-${code}`;
}

export async function createOrderFromCheckout(input: {
  user: AuthUser;
  items: Array<{productId: string; quantity: number}>;
  shippingAddress: ShippingAddress;
  paymentMethod: 'cod' | 'demo-invoice';
}): Promise<{order?: OrderRecord; error?: string; status?: number}> {
  if (!input.items || input.items.length === 0) {
    return {error: 'Your shopping cart is empty.', status: 400};
  }

  // Merge duplicate productIds defensively
  const consolidated = new Map<string, number>();
  for (const line of input.items) {
    const prev = consolidated.get(line.productId) || 0;
    consolidated.set(line.productId, prev + line.quantity);
  }

  const orderLines: OrderLineItem[] = [];
  let subtotal = 0;

  if (isMongoConnected()) {
    // Validate stock for all items before decrementing
    const productDocs = [];
    for (const [productId, quantity] of consolidated.entries()) {
      const doc = await ProductModel.findById(productId);
      if (!doc) {
        return {error: 'One or more selected products no longer exist.', status: 400};
      }
      if (doc.stock < quantity) {
        return {
          error: `Insufficient stock for "${doc.name}". Available: ${doc.stock}.`,
          status: 400,
        };
      }
      productDocs.push({doc, quantity});
    }

    for (const {doc, quantity} of productDocs) {
      doc.stock -= quantity;
      await doc.save();
      orderLines.push({
        productId: String(doc._id),
        name: doc.name,
        price: doc.price,
        quantity,
        imageUrl: doc.imageUrl,
      });
      subtotal += doc.price * quantity;
    }

    const shippingFee = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_FEE;
    const totalAmount = subtotal + shippingFee;

    const created = await OrderModel.create({
      orderNumber: generateOrderNumber(),
      userId: input.user.id,
      customerName: input.user.name,
      customerEmail: input.user.email,
      items: orderLines,
      shippingAddress: input.shippingAddress,
      paymentMethod: input.paymentMethod,
      subtotal,
      shippingFee,
      totalAmount,
      status: 'Pending',
    });

    await clearUserCart(input.user.id);
    return {order: mapMongoOrder(created)};
  }

  // Preview fallback store
  const selectedProducts: Array<{index: number; quantity: number}> = [];
  for (const [productId, quantity] of consolidated.entries()) {
    const idx = memoryDb.products.findIndex((p) => p.id === productId);
    if (idx === -1) {
      return {error: 'One or more selected products no longer exist.', status: 400};
    }
    const product = memoryDb.products[idx];
    if (product.stock < quantity) {
      return {
        error: `Insufficient stock for "${product.name}". Available: ${product.stock}.`,
        status: 400,
      };
    }
    selectedProducts.push({index: idx, quantity});
  }

  for (const {index, quantity} of selectedProducts) {
    const product = memoryDb.products[index];
    memoryDb.products[index] = {
      ...product,
      stock: product.stock - quantity,
      updatedAt: new Date().toISOString(),
    };
    orderLines.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity,
      imageUrl: product.imageUrl,
    });
    subtotal += product.price * quantity;
  }

  const shippingFee = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_FEE;
  const totalAmount = subtotal + shippingFee;
  const now = new Date().toISOString();

  const order: OrderRecord = {
    id: crypto.randomUUID(),
    orderNumber: generateOrderNumber(),
    userId: input.user.id,
    customerName: input.user.name,
    customerEmail: input.user.email,
    items: orderLines,
    shippingAddress: input.shippingAddress,
    paymentMethod: input.paymentMethod,
    subtotal,
    shippingFee,
    totalAmount,
    status: 'Pending',
    createdAt: now,
    updatedAt: now,
  };

  memoryDb.orders.unshift(order);
  await clearUserCart(input.user.id);
  await persistFallback();
  return {order};
}

export async function listUserOrders(userId: string): Promise<OrderRecord[]> {
  if (isMongoConnected()) {
    const docs = await OrderModel.find({userId}).sort({createdAt: -1}).lean();
    return docs.map((d) => mapMongoOrder(d));
  }
  return memoryDb.orders
    .filter((o) => o.userId === userId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function listAllOrders(): Promise<OrderRecord[]> {
  if (isMongoConnected()) {
    const docs = await OrderModel.find({}).sort({createdAt: -1}).lean();
    return docs.map((d) => mapMongoOrder(d));
  }
  return [...memoryDb.orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getOrderById(orderId: string): Promise<OrderRecord | null> {
  if (isMongoConnected()) {
    const doc = await OrderModel.findById(orderId).lean();
    return doc ? mapMongoOrder(doc) : null;
  }
  return memoryDb.orders.find((o) => o.id === orderId) || null;
}

export async function updateOrderStatus(
  orderId: string,
  status: OrderStatus,
): Promise<OrderRecord | null> {
  if (isMongoConnected()) {
    const doc = await OrderModel.findByIdAndUpdate(orderId, {status}, {new: true}).lean();
    return doc ? mapMongoOrder(doc) : null;
  }
  const idx = memoryDb.orders.findIndex((o) => o.id === orderId);
  if (idx === -1) {
    return null;
  }
  memoryDb.orders[idx] = {
    ...memoryDb.orders[idx],
    status,
    updatedAt: new Date().toISOString(),
  };
  await persistFallback();
  return memoryDb.orders[idx];
}
