import 'dotenv/config';
import {createApiApp} from './app.ts';
import {connectDatabase} from './config/db.ts';
import {initializeStoreDatabase} from './services/storeDb.ts';

async function startBackendOnly() {
  await connectDatabase();
  await initializeStoreDatabase();

  const app = createApiApp();
  const port = Number(process.env.PORT) || 5000;

  app.get('/', (_req, res) => {
    res.json({
      success: true,
      service: 'Kanso Goods E-Commerce REST API',
      endpoints: ['/api/health', '/api/auth', '/api/products', '/api/cart', '/api/orders'],
    });
  });

  app.listen(port, '0.0.0.0', () => {
    console.info(`[Backend API] Kanso Goods API listening on http://localhost:${port}`);
  });
}

startBackendOnly().catch((error) => {
  console.error('[Backend Startup Error]', error);
  process.exit(1);
});
