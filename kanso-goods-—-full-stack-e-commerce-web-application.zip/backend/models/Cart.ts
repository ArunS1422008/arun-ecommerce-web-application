import mongoose, {Schema, type Document} from 'mongoose';

export interface CartDocument extends Document {
  userId: mongoose.Types.ObjectId;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
  updatedAt: Date;
}

const CartSchema = new Schema<CartDocument>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    items: [
      {
        productId: {type: String, required: true},
        quantity: {type: Number, required: true, min: 1},
      },
    ],
  },
  {timestamps: true, collection: 'carts'},
);

export const CartModel =
  (mongoose.models.Cart as mongoose.Model<CartDocument>) ||
  mongoose.model<CartDocument>('Cart', CartSchema);
