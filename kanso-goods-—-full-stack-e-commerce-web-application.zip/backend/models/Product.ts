import mongoose, {Schema, type Document} from 'mongoose';
import type {ProductCategory} from '../../src/types/store.ts';

export interface ProductDocument extends Document {
  slug: string;
  name: string;
  category: ProductCategory;
  price: number;
  stock: number;
  description: string;
  specs: string[];
  imageUrl: string;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ProductSchema = new Schema<ProductDocument>(
  {
    slug: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120,
    },
    category: {
      type: String,
      enum: ['Keyboards', 'Audio', 'Lighting', 'Accessories'],
      required: true,
    },
    price: {
      type: Number,
      required: true,
      min: 1,
    },
    stock: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    description: {
      type: String,
      required: true,
      trim: true,
      maxlength: 1200,
    },
    specs: [{type: String, trim: true}],
    imageUrl: {
      type: String,
      required: true,
      trim: true,
    },
    featured: {
      type: Boolean,
      default: false,
    },
  },
  {timestamps: true, collection: 'products'},
);

export const ProductModel =
  (mongoose.models.Product as mongoose.Model<ProductDocument>) ||
  mongoose.model<ProductDocument>('Product', ProductSchema);
