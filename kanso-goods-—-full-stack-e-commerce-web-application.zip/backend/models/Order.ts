import mongoose, {Schema, type Document} from 'mongoose';
import type {OrderLineItem, OrderStatus, ShippingAddress} from '../../src/types/store.ts';

export interface OrderDocument extends Document {
  orderNumber: string;
  userId: mongoose.Types.ObjectId;
  customerName: string;
  customerEmail: string;
  items: OrderLineItem[];
  shippingAddress: ShippingAddress;
  paymentMethod: 'cod' | 'demo-invoice';
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  status: OrderStatus;
  createdAt: Date;
  updatedAt: Date;
}

const OrderSchema = new Schema<OrderDocument>(
  {
    orderNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    customerName: {type: String, required: true, trim: true},
    customerEmail: {type: String, required: true, trim: true},
    items: [
      {
        productId: {type: String, required: true},
        name: {type: String, required: true},
        price: {type: Number, required: true},
        quantity: {type: Number, required: true, min: 1},
        imageUrl: {type: String, required: true},
      },
    ],
    shippingAddress: {
      fullName: {type: String, required: true, trim: true},
      phone: {type: String, required: true, trim: true},
      street: {type: String, required: true, trim: true},
      city: {type: String, required: true, trim: true},
      state: {type: String, required: true, trim: true},
      postalCode: {type: String, required: true, trim: true},
    },
    paymentMethod: {
      type: String,
      enum: ['cod', 'demo-invoice'],
      default: 'cod',
    },
    subtotal: {type: Number, required: true, min: 0},
    shippingFee: {type: Number, required: true, min: 0},
    totalAmount: {type: Number, required: true, min: 0},
    status: {
      type: String,
      enum: ['Pending', 'Processing', 'Shipped', 'Delivered'],
      default: 'Pending',
      required: true,
    },
  },
  {timestamps: true, collection: 'orders'},
);

export const OrderModel =
  (mongoose.models.Order as mongoose.Model<OrderDocument>) ||
  mongoose.model<OrderDocument>('Order', OrderSchema);
