import {Router, type NextFunction, type Response} from 'express';
import {requireAuth, type AuthenticatedRequest} from '../middleware/auth.ts';
import {isValidEntityId} from '../middleware/validate.ts';
import {
  addToUserCart,
  clearUserCart,
  getUserCart,
  mergeGuestCart,
  removeUserCartItem,
  updateUserCartItem,
} from '../services/storeDb.ts';

const router = Router();

router.use(requireAuth);

router.get('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const cart = await getUserCart(req.user!.id);
    res.json({success: true, data: cart});
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const body = (req.body || {}) as Record<string, unknown>;
    const quantity = Number(body.quantity ?? 1);
    if (!isValidEntityId(body.productId) || !Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
      res.status(400).json({
        success: false,
        message: 'Valid productId and quantity (1–50) are required.',
      });
      return;
    }

    const result = await addToUserCart(req.user!.id, body.productId.trim(), quantity);
    if (result.error) {
      res.status(result.status || 400).json({success: false, message: result.error});
      return;
    }

    res.json({
      success: true,
      message: 'Added to shopping cart.',
      data: result.cart,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/merge', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const rawItems = (req.body as Record<string, unknown>)?.items;
    if (!Array.isArray(rawItems)) {
      res.status(400).json({success: false, message: 'Cart items array is required.'});
      return;
    }

    const clean: Array<{productId: string; quantity: number}> = [];
    for (const item of rawItems) {
      if (!item || typeof item !== 'object') continue;
      const entry = item as Record<string, unknown>;
      const qty = Number(entry.quantity);
      if (isValidEntityId(entry.productId) && Number.isInteger(qty) && qty >= 1 && qty <= 50) {
        clean.push({productId: entry.productId.trim(), quantity: qty});
      }
    }

    const cart = await mergeGuestCart(req.user!.id, clean);
    res.json({success: true, data: cart});
  } catch (error) {
    next(error);
  }
});

router.patch('/:productId', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const {productId} = req.params;
    const quantity = Number((req.body as Record<string, unknown>)?.quantity);

    if (!isValidEntityId(productId) || !Number.isInteger(quantity) || quantity < 0 || quantity > 50) {
      res.status(400).json({
        success: false,
        message: 'Valid productId and quantity (0–50) are required.',
      });
      return;
    }

    const result = await updateUserCartItem(req.user!.id, productId.trim(), quantity);
    if (result.error) {
      res.status(result.status || 400).json({success: false, message: result.error});
      return;
    }

    res.json({success: true, data: result.cart});
  } catch (error) {
    next(error);
  }
});

router.delete('/:productId', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const {productId} = req.params;
    if (!isValidEntityId(productId)) {
      res.status(400).json({success: false, message: 'Invalid product identifier.'});
      return;
    }

    const cart = await removeUserCartItem(req.user!.id, productId.trim());
    res.json({success: true, data: cart});
  } catch (error) {
    next(error);
  }
});

router.delete('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    await clearUserCart(req.user!.id);
    res.json({success: true, data: []});
  } catch (error) {
    next(error);
  }
});

export default router;
