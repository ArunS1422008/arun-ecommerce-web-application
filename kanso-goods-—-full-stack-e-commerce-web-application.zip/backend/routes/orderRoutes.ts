import {Router, type NextFunction, type Response} from 'express';
import {requireAdmin, requireAuth, type AuthenticatedRequest} from '../middleware/auth.ts';
import {
  isValidEntityId,
  isValidOrderStatus,
  validateCheckoutBody,
} from '../middleware/validate.ts';
import {
  createOrderFromCheckout,
  getOrderById,
  listAllOrders,
  listUserOrders,
  updateOrderStatus,
} from '../services/storeDb.ts';

const router = Router();

router.use(requireAuth);

router.post('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const validation = validateCheckoutBody(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please verify your shipping and order details.',
        errors: validation.errors,
      });
      return;
    }

    const result = await createOrderFromCheckout({
      user: req.user!,
      items: validation.data.items,
      shippingAddress: validation.data.shippingAddress,
      paymentMethod: validation.data.paymentMethod,
    });

    if (result.error || !result.order) {
      res.status(result.status || 400).json({
        success: false,
        message: result.error || 'Unable to place order.',
      });
      return;
    }

    res.status(201).json({
      success: true,
      message: `Order ${result.order.orderNumber} confirmed.`,
      data: result.order,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/mine', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const orders = await listUserOrders(req.user!.id);
    res.json({
      success: true,
      count: orders.length,
      data: orders,
    });
  } catch (error) {
    next(error);
  }
});

router.get(
  '/all',
  requireAdmin,
  async (_req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const orders = await listAllOrders();
      res.json({
        success: true,
        count: orders.length,
        data: orders,
      });
    } catch (error) {
      next(error);
    }
  },
);

router.get('/:id', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const {id} = req.params;
    if (!isValidEntityId(id)) {
      res.status(400).json({success: false, message: 'Invalid order identifier.'});
      return;
    }

    const order = await getOrderById(id);
    if (!order) {
      res.status(404).json({success: false, message: 'Order not found.'});
      return;
    }

    if (order.userId !== req.user!.id && req.user!.role !== 'admin') {
      res.status(403).json({
        success: false,
        message: 'You do not have permission to view this order.',
      });
      return;
    }

    res.json({success: true, data: order});
  } catch (error) {
    next(error);
  }
});

router.patch(
  '/:id/status',
  requireAdmin,
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const {id} = req.params;
      if (!isValidEntityId(id)) {
        res.status(400).json({success: false, message: 'Invalid order identifier.'});
        return;
      }

      const rawStatus = (req.body as Record<string, unknown>)?.status;
      if (!isValidOrderStatus(rawStatus)) {
        res.status(400).json({
          success: false,
          message: 'Status must be Pending, Processing, Shipped, or Delivered.',
        });
        return;
      }

      const updated = await updateOrderStatus(id, rawStatus);
      if (!updated) {
        res.status(404).json({success: false, message: 'Order not found.'});
        return;
      }

      res.json({
        success: true,
        message: `Order ${updated.orderNumber} updated to ${updated.status}.`,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  },
);

export default router;
