import {Router, type NextFunction, type Request, type Response} from 'express';
import {signAuthToken} from '../config/auth.ts';
import {requireAuth, type AuthenticatedRequest} from '../middleware/auth.ts';
import {
  authRateLimiter,
  validateAuthLogin,
  validateAuthRegister,
} from '../middleware/validate.ts';
import {
  authenticateAccount,
  createAccount,
  hasAdminAccount,
  updateUserDisplayName,
} from '../services/storeDb.ts';

const router = Router();

router.get('/admin-status', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const adminClaimed = await hasAdminAccount();
    res.json({
      success: true,
      adminClaimed,
      requiresSetupKey: Boolean((process.env.ADMIN_SETUP_KEY || '').trim()),
    });
  } catch (error) {
    next(error);
  }
});

router.post(
  '/bootstrap-admin',
  authRateLimiter,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const alreadyClaimed = await hasAdminAccount();
      if (alreadyClaimed) {
        res.status(409).json({
          success: false,
          message: 'Store administrator account has already been claimed. Please sign in.',
        });
        return;
      }

      const validation = validateAuthRegister(req.body);
      if (!validation.valid || !validation.data) {
        res.status(400).json({
          success: false,
          message: 'Please correct the admin setup fields.',
          errors: validation.errors,
        });
        return;
      }

      const requiredKey = (process.env.ADMIN_SETUP_KEY || '').trim();
      if (requiredKey && validation.data.setupKey !== requiredKey) {
        res.status(403).json({
          success: false,
          message: 'Invalid admin setup key.',
          errors: {setupKey: 'Setup key does not match server configuration.'},
        });
        return;
      }

      const result = await createAccount({
        name: validation.data.name,
        email: validation.data.email,
        password: validation.data.password,
        role: 'admin',
      });

      if (result.conflict || !result.user) {
        res.status(409).json({
          success: false,
          message: 'An account with this email already exists.',
          errors: {email: 'Email is already registered.'},
        });
        return;
      }

      const token = signAuthToken({
        sub: result.user.id,
        email: result.user.email,
        name: result.user.name,
        role: result.user.role,
      });

      res.status(201).json({
        success: true,
        message: 'Store administrator account created.',
        token,
        user: result.user,
      });
    } catch (error) {
      next(error);
    }
  },
);

router.post('/register', authRateLimiter, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const validation = validateAuthRegister(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please fix the highlighted registration fields.',
        errors: validation.errors,
      });
      return;
    }

    // Always enforce role: 'customer' on public registration
    const result = await createAccount({
      name: validation.data.name,
      email: validation.data.email,
      password: validation.data.password,
      role: 'customer',
    });

    if (result.conflict || !result.user) {
      res.status(409).json({
        success: false,
        message: 'An account with this email address already exists.',
        errors: {email: 'This email is already registered.'},
      });
      return;
    }

    const token = signAuthToken({
      sub: result.user.id,
      email: result.user.email,
      name: result.user.name,
      role: result.user.role,
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully.',
      token,
      user: result.user,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/login', authRateLimiter, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const validation = validateAuthLogin(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please enter a valid email address and password.',
        errors: validation.errors,
      });
      return;
    }

    const user = await authenticateAccount(validation.data.email, validation.data.password);
    if (!user) {
      res.status(401).json({
        success: false,
        message: 'Invalid email address or password.',
      });
      return;
    }

    const token = signAuthToken({
      sub: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    });

    res.json({
      success: true,
      message: 'Signed in successfully.',
      token,
      user,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  res.json({
    success: true,
    message: 'Signed out successfully.',
  });
});

router.get('/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  res.json({
    success: true,
    user: req.user,
  });
});

router.patch('/profile', requireAuth, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const rawName = (req.body as Record<string, unknown>)?.name;
    if (typeof rawName !== 'string' || rawName.trim().length < 2 || rawName.trim().length > 80) {
      res.status(400).json({
        success: false,
        message: 'Display name must be between 2 and 80 characters.',
      });
      return;
    }

    const updated = await updateUserDisplayName(req.user!.id, rawName);
    if (!updated) {
      res.status(404).json({success: false, message: 'User account not found.'});
      return;
    }

    res.json({
      success: true,
      message: 'Profile updated successfully.',
      user: updated,
    });
  } catch (error) {
    next(error);
  }
});

export default router;
