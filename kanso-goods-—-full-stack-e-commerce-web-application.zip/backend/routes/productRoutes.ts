import {Router, type NextFunction, type Request, type Response} from 'express';
import {requireAdmin, requireAuth} from '../middleware/auth.ts';
import {
  isValidEntityId,
  parseProductQuery,
  validateProductPayload,
} from '../middleware/validate.ts';
import {
  createProduct,
  deleteProduct,
  getProductByIdOrSlug,
  listProducts,
  updateProduct,
} from '../services/storeDb.ts';
import type {ProductFormPayload} from '../../src/types/store.ts';

const router = Router();

router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const query = parseProductQuery(req.query as Record<string, unknown>);
    const products = await listProducts(query);
    res.json({
      success: true,
      count: products.length,
      data: products,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:idOrSlug', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const rawParam = req.params.idOrSlug;
    if (typeof rawParam !== 'string' || !/^[a-z0-9-]+$/i.test(rawParam)) {
      res.status(400).json({success: false, message: 'Invalid product identifier.'});
      return;
    }

    const product = await getProductByIdOrSlug(rawParam);
    if (!product) {
      res.status(404).json({success: false, message: 'Product not found.'});
      return;
    }

    res.json({success: true, data: product});
  } catch (error) {
    next(error);
  }
});

router.post(
  '/',
  requireAuth,
  requireAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const validation = validateProductPayload(req.body, false);
      if (!validation.valid || !validation.data) {
        res.status(400).json({
          success: false,
          message: 'Please correct the product fields and try again.',
          errors: validation.errors,
        });
        return;
      }

      const created = await createProduct(validation.data as ProductFormPayload);
      res.status(201).json({
        success: true,
        message: 'Product added to catalog.',
        data: created,
      });
    } catch (error) {
      next(error);
    }
  },
);

router.put(
  '/:id',
  requireAuth,
  requireAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const {id} = req.params;
      if (!isValidEntityId(id)) {
        res.status(400).json({success: false, message: 'Invalid product ID format.'});
        return;
      }

      const validation = validateProductPayload(req.body, true);
      if (!validation.valid || !validation.data) {
        res.status(400).json({
          success: false,
          message: 'Please correct the updated product fields.',
          errors: validation.errors,
        });
        return;
      }

      const updated = await updateProduct(id, validation.data);
      if (!updated) {
        res.status(404).json({success: false, message: 'Product not found.'});
        return;
      }

      res.json({
        success: true,
        message: 'Product updated successfully.',
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  },
);

router.delete(
  '/:id',
  requireAuth,
  requireAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const {id} = req.params;
      if (!isValidEntityId(id)) {
        res.status(400).json({success: false, message: 'Invalid product ID format.'});
        return;
      }

      const deleted = await deleteProduct(id);
      if (!deleted) {
        res.status(404).json({success: false, message: 'Product not found.'});
        return;
      }

      res.json({
        success: true,
        message: 'Product removed from catalog.',
        deletedId: id,
      });
    } catch (error) {
      next(error);
    }
  },
);

export default router;
