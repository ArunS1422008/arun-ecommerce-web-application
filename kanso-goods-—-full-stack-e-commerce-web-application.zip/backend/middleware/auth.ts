import type {NextFunction, Request, Response} from 'express';
import {verifyAuthToken} from '../config/auth.ts';
import {findUserById} from '../services/storeDb.ts';
import type {AuthUser} from '../../src/types/store.ts';

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      message: 'Authentication required. Please sign in to continue.',
    });
    return;
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    res.status(401).json({
      success: false,
      message: 'Authentication token is missing.',
    });
    return;
  }

  try {
    const decoded = verifyAuthToken(token);
    const user = await findUserById(decoded.sub);
    if (!user) {
      res.status(401).json({
        success: false,
        message: 'User account no longer exists. Please sign in again.',
      });
      return;
    }

    req.user = user;
    next();
  } catch {
    res.status(401).json({
      success: false,
      message: 'Your session is invalid or expired. Please sign in again.',
    });
  }
}

export function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): void {
  if (!req.user) {
    res.status(401).json({
      success: false,
      message: 'Authentication required.',
    });
    return;
  }

  if (req.user.role !== 'admin') {
    res.status(403).json({
      success: false,
      message: 'Admin access required. You do not have permission for this action.',
    });
    return;
  }

  next();
}
