import type {NextFunction, Request, Response} from 'express';
import type {
  OrderStatus,
  ProductCategory,
  ProductFormPayload,
  ProductSortOption,
  ShippingAddress,
} from '../../src/types/store.ts';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ID_REGEX = /^([a-f0-9]{24}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;
const VALID_CATEGORIES = new Set<ProductCategory>(['Keyboards', 'Audio', 'Lighting', 'Accessories']);
const VALID_SORTS = new Set<ProductSortOption>(['featured', 'price-asc', 'price-desc']);
const VALID_ORDER_STATUSES = new Set<OrderStatus>(['Pending', 'Processing', 'Shipped', 'Delivered']);

interface RateBucket {
  count: number;
  resetAt: number;
}

const authBuckets = new Map<string, RateBucket>();

export function authRateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = authBuckets.get(ip);

  if (!bucket || now > bucket.resetAt) {
    authBuckets.set(ip, {count: 1, resetAt: now + 10 * 60 * 1000});
    next();
    return;
  }

  if (bucket.count >= 30) {
    res.status(429).json({
      success: false,
      message: 'Too many authentication attempts. Please wait a few minutes and try again.',
    });
    return;
  }

  bucket.count += 1;
  next();
}

export function isValidEntityId(value: unknown): value is string {
  return typeof value === 'string' && ID_REGEX.test(value.trim());
}

export function sanitizeProductImageUrl(raw: unknown): string | null {
  if (typeof raw !== 'string') {
    return null;
  }
  const trimmed = raw.trim();
  if (!trimmed) {
    return null;
  }
  if (trimmed.startsWith('/src/assets/images/') && !trimmed.includes('..')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function validateAuthRegister(body: unknown): {
  valid: boolean;
  data?: {name: string; email: string; password: string; setupKey?: string};
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request payload must be a JSON object.'}};
  }
  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (typeof raw.name !== 'string' || raw.name.trim().length < 2 || raw.name.trim().length > 80) {
    errors.name = 'Name must be between 2 and 80 characters.';
  }
  if (
    typeof raw.email !== 'string' ||
    raw.email.trim().length > 120 ||
    !EMAIL_REGEX.test(raw.email.trim())
  ) {
    errors.email = 'Please enter a valid email address.';
  }
  if (typeof raw.password !== 'string' || raw.password.length < 6 || raw.password.length > 72) {
    errors.password = 'Password must be between 6 and 72 characters.';
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      name: (raw.name as string).trim(),
      email: (raw.email as string).trim().toLowerCase(),
      password: raw.password as string,
      setupKey: typeof raw.setupKey === 'string' ? raw.setupKey.trim() : undefined,
    },
  };
}

export function validateAuthLogin(body: unknown): {
  valid: boolean;
  data?: {email: string; password: string};
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request payload must be a JSON object.'}};
  }
  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (typeof raw.email !== 'string' || !EMAIL_REGEX.test(raw.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (typeof raw.password !== 'string' || raw.password.length < 1 || raw.password.length > 72) {
    errors.password = 'Password is required.';
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      email: (raw.email as string).trim().toLowerCase(),
      password: raw.password as string,
    },
  };
}

export function validateProductPayload(
  body: unknown,
  isPartial = false,
): {
  valid: boolean;
  data?: Partial<ProductFormPayload>;
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request payload must be a JSON object.'}};
  }
  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};
  const data: Partial<ProductFormPayload> = {};

  if (!isPartial || raw.name !== undefined) {
    if (typeof raw.name !== 'string' || raw.name.trim().length < 2 || raw.name.trim().length > 120) {
      errors.name = 'Product name must be between 2 and 120 characters.';
    } else {
      data.name = raw.name.trim();
    }
  }

  if (!isPartial || raw.category !== undefined) {
    if (typeof raw.category !== 'string' || !VALID_CATEGORIES.has(raw.category as ProductCategory)) {
      errors.category = 'Category must be Keyboards, Audio, Lighting, or Accessories.';
    } else {
      data.category = raw.category as ProductCategory;
    }
  }

  if (!isPartial || raw.price !== undefined) {
    const price = typeof raw.price === 'number' ? raw.price : Number(raw.price);
    if (!Number.isFinite(price) || price < 1 || price > 1000000) {
      errors.price = 'Price must be a valid positive number.';
    } else {
      data.price = Math.round(price);
    }
  }

  if (!isPartial || raw.stock !== undefined) {
    const stock = typeof raw.stock === 'number' ? raw.stock : Number(raw.stock);
    if (!Number.isInteger(stock) || stock < 0 || stock > 100000) {
      errors.stock = 'Stock must be a whole number (0 or greater).';
    } else {
      data.stock = stock;
    }
  }

  if (!isPartial || raw.description !== undefined) {
    if (
      typeof raw.description !== 'string' ||
      raw.description.trim().length < 10 ||
      raw.description.trim().length > 1200
    ) {
      errors.description = 'Description must be between 10 and 1200 characters.';
    } else {
      data.description = raw.description.trim();
    }
  }

  if (raw.specs !== undefined) {
    if (!Array.isArray(raw.specs) || raw.specs.some((s) => typeof s !== 'string')) {
      errors.specs = 'Specifications must be a list of text lines.';
    } else {
      data.specs = raw.specs.map((s) => s.trim()).filter(Boolean).slice(0, 8);
    }
  } else if (!isPartial) {
    data.specs = [];
  }

  if (!isPartial || raw.imageUrl !== undefined) {
    const sanitized = sanitizeProductImageUrl(raw.imageUrl);
    if (!sanitized) {
      errors.imageUrl = 'Please provide a valid studio image path or https:// image URL.';
    } else {
      data.imageUrl = sanitized;
    }
  }

  if (raw.featured !== undefined) {
    data.featured = Boolean(raw.featured);
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {valid: true, data};
}

export function validateCheckoutBody(body: unknown): {
  valid: boolean;
  data?: {
    items: Array<{productId: string; quantity: number}>;
    shippingAddress: ShippingAddress;
    paymentMethod: 'cod' | 'demo-invoice';
  };
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request payload must be a JSON object.'}};
  }
  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (!Array.isArray(raw.items) || raw.items.length === 0) {
    errors.items = 'Your cart must contain at least one item.';
  }

  const cleanItems: Array<{productId: string; quantity: number}> = [];
  if (Array.isArray(raw.items)) {
    for (const item of raw.items) {
      if (!item || typeof item !== 'object') {
        errors.items = 'Invalid cart item format.';
        break;
      }
      const entry = item as Record<string, unknown>;
      const qty = Number(entry.quantity);
      if (!isValidEntityId(entry.productId) || !Number.isInteger(qty) || qty < 1 || qty > 50) {
        errors.items = 'Each item must have a valid product and quantity (1–50).';
        break;
      }
      cleanItems.push({productId: entry.productId.trim(), quantity: qty});
    }
  }

  const addr = (raw.shippingAddress && typeof raw.shippingAddress === 'object'
    ? raw.shippingAddress
    : {}) as Record<string, unknown>;

  if (typeof addr.fullName !== 'string' || addr.fullName.trim().length < 2 || addr.fullName.trim().length > 80) {
    errors.fullName = 'Full name is required (2–80 characters).';
  }
  if (typeof addr.phone !== 'string' || !/^[0-9+\-\s()]{7,20}$/.test(addr.phone.trim())) {
    errors.phone = 'Please enter a valid phone number.';
  }
  if (typeof addr.street !== 'string' || addr.street.trim().length < 5 || addr.street.trim().length > 160) {
    errors.street = 'Street address must be at least 5 characters.';
  }
  if (typeof addr.city !== 'string' || addr.city.trim().length < 2 || addr.city.trim().length > 60) {
    errors.city = 'City is required.';
  }
  if (typeof addr.state !== 'string' || addr.state.trim().length < 2 || addr.state.trim().length > 60) {
    errors.state = 'State is required.';
  }
  if (typeof addr.postalCode !== 'string' || !/^[A-Za-z0-9\-\s]{4,12}$/.test(addr.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code.';
  }

  const paymentMethod = raw.paymentMethod === 'demo-invoice' ? 'demo-invoice' : 'cod';

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      items: cleanItems,
      shippingAddress: {
        fullName: (addr.fullName as string).trim(),
        phone: (addr.phone as string).trim(),
        street: (addr.street as string).trim(),
        city: (addr.city as string).trim(),
        state: (addr.state as string).trim(),
        postalCode: (addr.postalCode as string).trim(),
      },
      paymentMethod,
    },
  };
}

export function parseProductQuery(query: Record<string, unknown>): {
  category?: ProductCategory;
  search?: string;
  sort?: ProductSortOption;
} {
  const result: {
    category?: ProductCategory;
    search?: string;
    sort?: ProductSortOption;
  } = {};

  if (typeof query.category === 'string' && VALID_CATEGORIES.has(query.category as ProductCategory)) {
    result.category = query.category as ProductCategory;
  }
  if (typeof query.search === 'string' && query.search.trim()) {
    result.search = query.search.trim().slice(0, 100);
  }
  if (typeof query.sort === 'string' && VALID_SORTS.has(query.sort as ProductSortOption)) {
    result.sort = query.sort as ProductSortOption;
  }
  return result;
}

export function isValidOrderStatus(status: unknown): status is OrderStatus {
  return typeof status === 'string' && VALID_ORDER_STATUSES.has(status as OrderStatus);
}
