# Kanso Goods — Full-Stack E-Commerce Web Application

**Thiranex Internship Project**  
Built by **Arun S** · 2nd Year, Computer Science and Engineering · **Easwari Engineering College, Chennai**

A full-stack MERN e-commerce storefront featuring product catalog browsing, live search/filtering/sorting, shopping cart management, safe demo checkout, role-based JWT authentication (Customer & Admin), order tracking, and an admin inventory/order console.

---

## Tech Stack

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Motion
- **Backend:** Node.js, Express.js, TypeScript (`tsx`)
- **Authentication & Security:** `bcryptjs` password hashing, `jsonwebtoken` (JWT), Role-Based Access Control (`customer` vs `admin`)
- **Database:** MongoDB with Mongoose ODM (`users`, `products`, `carts`, `orders`)

---

## Project Folder Structure

```text
arun-ecommerce-web-application/
├── backend/
│   ├── config/
│   │   ├── auth.ts                # JWT sign/verify & secret management
│   │   └── db.ts                  # MongoDB connection & preview fallback
│   ├── data/
│   │   └── seedProducts.ts        # Initial studio hardware product catalog
│   ├── middleware/
│   │   ├── auth.ts                # JWT requireAuth & requireAdmin middleware
│   │   ├── errorHandler.ts        # 404 & centralized error formatter
│   │   └── validate.ts            # Auth, product, checkout & query validators
│   ├── models/
│   │   ├── Cart.ts                # Mongoose Cart schema
│   │   ├── Order.ts               # Mongoose Order schema
│   │   ├── Product.ts             # Mongoose Product schema
│   │   └── User.ts                # Mongoose User schema (customer / admin)
│   ├── routes/
│   │   ├── authRoutes.ts          # Register, login, profile, admin bootstrap
│   │   ├── cartRoutes.ts          # Persistent user cart endpoints
│   │   ├── orderRoutes.ts         # Checkout, user orders, admin status updates
│   │   └── productRoutes.ts       # Public catalog + admin product CRUD
│   ├── services/
│   │   └── storeDb.ts             # MongoDB & fallback data access layer
│   ├── app.ts                     # Express app, CORS policy & routes
│   └── server.ts                  # Standalone backend server (split deploy)
├── src/
│   ├── assets/images/             # Studio product & hero photography
│   ├── components/
│   │   ├── AdminDashboardPage.tsx # Admin product CRUD & order status console
│   │   ├── AuthPages.tsx          # Login, registration & first-run admin claim
│   │   ├── CartPage.tsx           # Shopping cart quantity & total calculation
│   │   ├── CheckoutPage.tsx       # Safe COD / Demo order confirmation checkout
│   │   ├── Footer.tsx             # Storefront footer
│   │   ├── HomePage.tsx           # Hero, featured collection & store guarantees
│   │   ├── MediaFrame.tsx         # Resilient product image container
│   │   ├── Navbar.tsx             # Responsive navigation bar + mobile drawer
│   │   ├── OrdersPage.tsx         # My Orders history & 4-step status tracker
│   │   ├── ProductCard.tsx        # Uniform 4:3 product card
│   │   ├── ProductDetailPage.tsx  # Contiguous product gallery & purchase module
│   │   ├── ProductsPage.tsx       # Catalog search, category filter & price sort
│   │   └── ProfilePage.tsx        # User profile & display name management
│   ├── hooks/
│   │   └── useTheme.ts            # Light / Dark theme toggle hook
│   ├── services/
│   │   └── api.ts                 # Typed REST API client
│   ├── types/
│   │   └── store.ts               # Shared TypeScript interfaces
│   ├── utils/
│   │   └── currency.ts            # Currency formatting & shipping constants
│   ├── App.tsx                    # SPA routing, auth session & cart state
│   ├── index.css                  # Tailwind CSS v4 configuration
│   └── main.tsx                   # React root mount
├── server.ts                      # Unified Express + Vite server (port 3000)
├── .env.example                   # Environment variable template (no real secrets)
├── index.html                     # HTML entry & SEO metadata
└── package.json                   # Scripts and dependencies
```

---

## REST API Endpoints

### Authentication (`/api/auth`)
- `POST /api/auth/register` — Registers a customer account (`bcrypt` hashed password) and returns JWT
- `POST /api/auth/login` — Authenticates credentials and returns JWT
- `POST /api/auth/logout` — Signs out current session
- `GET /api/auth/me` — Returns current authenticated user
- `PATCH /api/auth/profile` — Updates user display name
- `GET /api/auth/admin-status` & `POST /api/auth/bootstrap-admin` — One-time first-run store admin claim (locked once claimed)

### Products (`/api/products`)
- `GET /api/products` — Lists products (`?category=`, `?search=`, `?sort=featured|price-asc|price-desc`)
- `GET /api/products/:idOrSlug` — Retrieves single product details
- `POST /api/products` *(Admin only)* — Adds new product
- `PUT /api/products/:id` *(Admin only)* — Updates product details or inventory stock
- `DELETE /api/products/:id` *(Admin only)* — Removes product

### Cart (`/api/cart`) *(Authenticated)*
- `GET /api/cart` — Retrieves user cart
- `POST /api/cart` — Adds item to cart (clamped to available stock)
- `POST /api/cart/merge` — Merges guest cart items on login
- `PATCH /api/cart/:productId` — Updates item quantity
- `DELETE /api/cart/:productId` & `DELETE /api/cart` — Removes item or clears cart

### Orders (`/api/orders`) *(Authenticated)*
- `POST /api/orders` — Validates stock, calculates subtotal/shipping/total on the server, decrements stock, and creates a `Pending` order
- `GET /api/orders/mine` — Retrieves logged-in customer's orders
- `GET /api/orders/all` *(Admin only)* — Retrieves all customer orders
- `PATCH /api/orders/:id/status` *(Admin only)* — Updates order status (`Pending` → `Processing` → `Shipped` → `Delivered`)

---

## Safe Demo Checkout Policy

This project uses a **safe demo checkout process** supporting Cash on Delivery (COD) and simulated order confirmation. It intentionally does **not** collect or process credit/debit card details.

---

## Installation & Running

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start development server (Express API + Vite frontend on port `3000`):
   ```bash
   npm run dev
   ```
3. Build production bundle:
   ```bash
   npm run build
   ```
4. Start production server:
   ```bash
   npm start
   ```

---

## Screenshots

> Add screenshots inside a `screenshots/` folder before final submission:
> - `screenshots/home-storefront.png`
> - `screenshots/product-catalog.png`
> - `screenshots/cart-checkout.png`
> - `screenshots/orders-tracking.png`
> - `screenshots/admin-dashboard.png`
